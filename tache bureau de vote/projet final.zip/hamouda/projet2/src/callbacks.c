#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "BV.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"

int choix[2]={0,0};
int choice=1;
void
on_ajoutBV_clicked                     (GtkWidget        *objet,
                                        gpointer         user_data)
{
	GtkWidget *Windowajout;
	GtkWidget *acceuil;
	Windowajout=lookup_widget(objet,"Windowajout");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	Windowajout=create_Windowajout();
	gtk_widget_show(Windowajout);

	
}


void
on_modifierBV_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowmodifier;
	GtkWidget *acceuil;

	windowmodifier=lookup_widget(objet,"windowmodifier");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	windowmodifier=create_windowmodifier();
	gtk_widget_show(windowmodifier);
	
	
}


void
on_supprimerBV_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowsupprimer;
	GtkWidget *acceuil;
	windowsupprimer=lookup_widget(objet,"windowsupprimer");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	windowsupprimer=create_windowsupprimer();
	gtk_widget_show(windowsupprimer);
	
}


void
on_afficherBV_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *acceuil;
	GtkWidget *windowafficher;
	GtkWidget *treeviewafichage;
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	windowafficher=lookup_widget(objet,"windowafficher");

	windowafficher=create_windowafficher();
	gtk_widget_show(windowafficher);
	
	
	treeviewafichage=lookup_widget(windowafficher,"treeviewafichage");
	vider(treeviewafichage);
	afficher(treeviewafichage);

	
}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Windowajout,*acceuil;
	Windowajout=lookup_widget(objet,"Windowajout");
	gtk_widget_destroy(Windowajout);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
	
}


void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int x=-1;
	bureau b1,p;
	GtkWidget *input1,*input2,*input3,*input4;
	GtkWidget *output;
	GtkWidget *Windowajout;
	GtkWidget *combobox1;
	GtkWidget *spinbutton;
	int k;
	char vide[2]="";
	GtkWidget *output1 ;
	GtkWidget *output2 ;
	GtkWidget *output3 ;
	GtkWidget *output4 ;
	GtkWidget *output5 ;

	

	char mot2[20]="echec d ajout  ";
	char mot3[20]="(invalide)";
	char mot7[25]="";
	output1=lookup_widget(objet, "label46") ;
	output2=lookup_widget(objet, "label47") ;
	output3=lookup_widget(objet, "label48") ;
	output4=lookup_widget(objet, "label49") ;
	output5=lookup_widget(objet, "label50") ;
	int a,b,c,d;

	Windowajout=lookup_widget(objet,"Windowajout");
	input1=lookup_widget(objet,"IDBV");
	input2=lookup_widget(objet,"capobservateur");
	input3=lookup_widget(objet,"capelecteur");
	input4=lookup_widget(objet,"IDagent");
	combobox1=lookup_widget(objet,"gouv1");
	//gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1));
	spinbutton=lookup_widget(objet,"spinbuttonsalle");
	b1.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton));
	output=lookup_widget(objet,"label45");

	strcpy(b1.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(b1.cap_elec,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(b1.cap_obs,gtk_entry_get_text(GTK_ENTRY(input3)));
	if ((gtk_combo_box_get_active(GTK_COMBO_BOX(combobox1)))!=-1)
		strcpy(b1.b_adr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(b1.id_agentb,gtk_entry_get_text(GTK_ENTRY(input4)));
	a=controlle(b1.id);
	b=controlle(b1.cap_elec);
	c=controlle(b1.cap_obs);
	d=controlle(b1.id_agentb);
	FILE * f=fopen("BV.txt", "r");
	
	if (f!=NULL)
 	{
  		while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
  		{
    			if(strcmp(b1.id,p.id)==0)
				x=1;
  		}
	fclose (f);
  	}
	if (x==1)
	{
	gtk_label_set_text(GTK_LABEL(output),mot2);
	gtk_label_set_text(GTK_LABEL(output1),"id déja utilisé :)");
	}

	else

	{

if ((strcmp(b1.id,vide )!=0) && (strcmp(b1.cap_elec,vide )!=0) && (strcmp(b1.cap_obs,vide )!=0) && (strcmp(b1.b_adr,vide )!=0) && (strcmp(b1.id_agentb,"")!=0) &&(a==1)&&(b==1)&&(d==1)&&(c==1))
	{
		ajouter(b1);
		gtk_label_set_text(GTK_LABEL(output),"Bureau De Vote ajouté avec succés :)");
		gtk_label_set_text(GTK_LABEL(output1),vide);
		gtk_label_set_text(GTK_LABEL(output2),vide);
		gtk_label_set_text(GTK_LABEL(output3),vide);
		gtk_label_set_text(GTK_LABEL(output4),vide);
		gtk_label_set_text(GTK_LABEL(output5),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input4),vide);	
		gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),-1);
		
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output),mot2);
		gtk_label_set_text(GTK_LABEL(output1),mot3);
		gtk_label_set_text(GTK_LABEL(output2),mot3);
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		gtk_label_set_text(GTK_LABEL(output4),mot3);
		gtk_label_set_text(GTK_LABEL(output5),mot3);
		
	}
}
	
}


void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowmodifier,*acceuil;
	windowmodifier=lookup_widget(objet,"windowmodifier");
	gtk_widget_destroy(windowmodifier);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}


void
on_buttonMofier_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{	
	
	char vide[2]="";
	bureau b2;
	GtkWidget *input1,*input2,*input3,*input4;
	GtkWidget *windowmodifier;
	GtkWidget *combobox2;
	GtkWidget *output53;
	GtkWidget *spinsalle;

	windowmodifier=lookup_widget(objet,"windowmodifier");
	input1=lookup_widget(objet,"entry7");
	input2=lookup_widget(objet,"entry8");
	input3=lookup_widget(objet,"entry10");
	input4=lookup_widget(objet,"entry12");
	spinsalle=lookup_widget(objet,"salle1");
	b2.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinsalle));
	combobox2=lookup_widget(objet,"gouv2");
	output53=lookup_widget(objet,"label53");
	

	
	strcpy(b2.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(b2.cap_elec,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(b2.cap_obs,gtk_entry_get_text(GTK_ENTRY(input3)));
	if ((gtk_combo_box_get_active(GTK_COMBO_BOX(combobox2)))!=-1)
		strcpy(b2.b_adr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	strcpy(b2.id_agentb,gtk_entry_get_text(GTK_ENTRY(input4)));
	if ((strcmp(b2.id,vide )!=0) && (strcmp(b2.cap_elec,vide )!=0) && (strcmp(b2.cap_obs,vide )!=0) && (strcmp(b2.b_adr,vide )!=0) && (strcmp(b2.id_agentb,"")!=0))
	{
		modifier(b2);
		gtk_label_set_text(GTK_LABEL(output53),"Bureau De Vote modifié avec succés :)");
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input4),vide);	
		gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),-1);
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output53),"Echech de modification :( ");
		
	}


}


void
on_buttonsupp2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	bureau b3,p;
	GtkWidget *input,*output;
	char id[20];
	int x=-1;
	
	GtkWidget *windowsupprimer,*windowsuppression;
	
	windowsupprimer=lookup_widget(objet,"windowsupprimer");
	
	input=lookup_widget(objet,"entryIDsup");
	output=lookup_widget(objet,"label44");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	//supprimer(b3,choice);
	FILE * f=fopen("BV.txt", "r");
	
	if (f!=NULL)
 	{
  		while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
  		{
    			if(strcmp(id,p.id)==0)
				x=1;
  		}
	fclose (f);
  	}
	
	if ((strcmp(id,"")!=0)&&(x==1))
	{
		supprimer_1(id);
		windowsuppression=create_windowsuppression();
		gtk_widget_show(windowsuppression);
		gtk_label_set_text(GTK_LABEL(output),"votre choix eté fait avec succés :)");
		}
	else 
		gtk_label_set_text(GTK_LABEL(output),"id introuvable");

}


void
on_retoursupp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowsupprimer,*acceuil;
	windowsupprimer=lookup_widget(objet,"windowsupprimer");
	gtk_widget_destroy(windowsupprimer);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}


void
on_treeviewafichage_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* id;
	gchar* cap_elec;
	gchar* cap_obs;
	gchar* b_adr;  
	gchar* id_agentb;
	
	bureau b;
	GtkTreeModel *model = gtk_tree_view_get_model (treeview) ;

	if (gtk_tree_model_get_iter(model, &iter, path) )
	{

		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id, 1, &cap_elec,2,&cap_obs,3,&b_adr,4,&id_agentb,-1);
		strcpy(b.id,id);
		strcpy(b.cap_elec,cap_elec) ;
		strcpy(b.cap_obs,cap_obs) ;
		strcpy(b.b_adr,b_adr);
		strcpy(b.id_agentb,id_agentb);
		supprimer(b,choice);
		afficher(treeview);
	}

}
void
on_retour5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowafficher,*acceuil;
	windowafficher=lookup_widget(objet,"windowafficher");
	gtk_widget_destroy(windowafficher);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}


void
on_buttonchercher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char vide[3]="";
	char id[20];
	char salle[20];
	bureau p;
	int x=-1;
	GtkWidget *input,*output1,*output2,*output3,*output4,*output5,*output55;
	GtkWidget *windowmodifier;
		

	windowmodifier=lookup_widget(objet,"windowmodifier");
	input=lookup_widget(objet,"entry7");
	output1=lookup_widget(objet,"entry8");
	output2=lookup_widget(objet,"entry10");
	output3=lookup_widget(objet,"entry12");
	//output4=lookup_widget(objet,"entry13");
	output5=lookup_widget(objet,"gouv2");
	output55=lookup_widget(objet,"label55");
	char gouv[25][50]={" ","ariana","beja","ben_arous","bizerte","gabes","gafsa","jendouba","kairouan","kasserine","kebili","kef","mahdia","manouba","mednine","monastir","nabeul","sfax","sidi_bouzid","siliana","sousse","tataouine","tozeur","tunis","zaghouan"};
	
	int i=0;

	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	FILE * f=fopen("BV.txt", "r");
	
	if (f!=NULL)
 	{
  		while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
  		{
    			if(strcmp(id,p.id)==0)
				x=1;
  		}
	fclose (f);
  	}
	if(x==1)

	{
		bureau p2=chercher(id);
		gtk_entry_set_text(GTK_ENTRY(output1),p2.cap_elec);
		gtk_entry_set_text(GTK_ENTRY(output2),p2.cap_obs);
		gtk_entry_set_text(GTK_ENTRY(output3),p2.id_agentb);
		//sprintf(salle,"%d",p2.salle);
		while (i<25 && strcmp(gouv[i],p2.b_adr)!=0){
			i++;
		}
		gtk_combo_box_set_active(GTK_COMBO_BOX(output5),i);//entier
		//gtk_entry_set_text(GTK_ENTRY(output5),p2.b_adr);
		gtk_label_set_text(GTK_LABEL(output55),"Bureau De Vote trouvé :)");
	}	
	else {
		gtk_entry_set_text(GTK_ENTRY(output1),vide);
		gtk_entry_set_text(GTK_ENTRY(output2),vide);
		gtk_entry_set_text(GTK_ENTRY(output3),vide);
		//gtk_entry_set_text(GTK_ENTRY(output4),vide);
		gtk_entry_set_text(GTK_ENTRY(output5),vide);
		gtk_label_set_text(GTK_LABEL(output55),"Bureau De Vote introuvable :)");
		
}
x=-1;

}	


void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	bureau b3;
	GtkWidget *output;
	GtkWidget *input;
	GtkWidget *windowsupprimer;
	GtkWidget *windowsuppression;
	
	windowsuppression=lookup_widget(objet,"windowsuppression");
	//windowsupprimer=lookup_widget(objet,"windowsupprimer");
	


	
	//output=lookup_widget(objet,"label44");
	validation(choice);	
	choice =1;
	gtk_widget_destroy(windowsuppression);
	

	//gtk_label_set_text(GTK_LABEL(output),"Bureau De Vote supprimé avec succés :)");	
	//gtk_widget_destroy(windowsuppression);
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choice=1;
}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choice=2;
}
}


void
on_vb_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
	choix[0]=1;
}
}


void
on_nbrelec_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
	choix[1]=1;
}
}


void
on_stat_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *stat;
	GtkWidget *acceuil;
	stat=lookup_widget(objet,"stat");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	stat=create_stat();
	gtk_widget_show(stat);
}


void
on_afficherstat_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
char tv[10];
int vote_blanc;
GtkWidget *output,*tg;
output =lookup_widget(objet,"labelnbrelec");
tg =lookup_widget(objet,"vb");
vote_blanc =tvb ();
sprintf(tv,"%d",vote_blanc);    
if (gtk_toggle_button_get_active(tg)==1)
	gtk_label_set_text(GTK_LABEL(output),tv);
if (gtk_toggle_button_get_active(tg)==0)
	gtk_label_set_text(GTK_LABEL(output),"");
}


void
on_retourstat_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *stat;
	GtkWidget *acceuil;
	stat=lookup_widget(objet,"stat");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(stat);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}

