#ifndef FONCTIONS_H_
#define FONCTIONS_H_
#include <stdio.h>
#include <gtk/gtk.h>
typedef struct 
{
char id[20];
char cap_elec[20];
char cap_obs[20];
int salle;
char b_adr[20];  
char  id_agentb[20];
} bureau ;


int ajouter( bureau b);
void modifier( bureau b);
int controlle(char chaine[]);
void supprimer( bureau p ,int choice);
bureau chercher(char id[]);
void afficher (GtkWidget *liste);
void validation (int choice );
int supprimer_1( char id[]);
int tvb();
#endif
