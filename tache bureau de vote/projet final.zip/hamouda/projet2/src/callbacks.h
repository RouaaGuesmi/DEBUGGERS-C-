#include <gtk/gtk.h>


void
on_ajoutBV_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifierBV_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerBV_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherBV_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonMofier_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonsupp2_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retoursupp_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeviewafichage_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_suppvalid_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonchercher_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajout_affiche_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_vb_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nbrelec_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_stat_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherstat_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourstat_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);
