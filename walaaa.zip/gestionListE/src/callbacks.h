#include <gtk/gtk.h>



void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_vider_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_enregistrer_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimer2_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rechercher2_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_stat_clicked                        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobuttonAG_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAC_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonAD_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_annuler_ajout_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterLE_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

/* ---------------------------- INTERFACE Modifier/Supp ------------------------------- */

void
on_consulterLE_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonGE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonCE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonDE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_supprimerLE_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_saveChangesLE_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherLE_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toAffLE_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toAddLE_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toModLE_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toVote_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toStats_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_voter_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refreshTreeView_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refreshStat1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_refreshStat2_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbuttonajout_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonmodif_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);














void
on_ajouterobsmenu_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichageobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radioHA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radioFA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retourAjoutObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourAffichageObs_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmAjoutObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewObs_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficherObs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherStats_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_menustatsobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourStats_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercherObs_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radioHM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radioFM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_enregistrerModObs_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourModifObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierParmObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerObservateur_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirm_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_reclamation_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);
void
on_ajoutBV_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_modifierBV_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimerBV_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherBV_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button13_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button11_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonMofier_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonsupp2_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retoursupp_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeviewafichage_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour5_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_suppvalid_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonchercher_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajout_affiche_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_confirmer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_vb_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_nbrelec_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_afficherstat_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourstat_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_statbv_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retourbv_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonlogin_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);
