#include <stdlib.h>
#include <stdbool.h>
#include "election.h"
#include "callbacks.h"
#include <gtk/gtk.h>

enum{
	EID,
	ENOM,
	EORIENTATION,
	ENOMCT,
	ECINT,
	ENOMC1,
	ECINC1,
	ENOMC2,
	ECINC2,
	ENOMC3,
	ECINC3,
	ENBVOTES,
	ECOLUMNS,
};

enum{
	EIDS,
	ENOMS,
	ENBVOTESS,
	ECOLUMNSS,
};

enum{
	EIDSS,
	ENOMSS,
	ENOMCTS,
	ECINTS,
	ENBVOTESSS,
	ECOLUMNSSS,
};










void ajouter(election e){
	e.nbrVote = 0 ;
    FILE *f;
    f = fopen("election.txt","a");
    if(f!= NULL){
        fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,e.nbrVote);
    }
    fclose(f);
}











void supprimer(char id[])
{
election e;
FILE *f, *g;
f=fopen("election.txt","r");
g=fopen("temp.txt","a");
if(f!=NULL&&g!=NULL){
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF)
	{
		if(strcmp(e.id,id))
			fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,e.nbrVote);
	}
	
	fclose(f);
	fclose(g);
	
	remove("election.txt");
	rename("temp.txt","election.txt");
	}
}










void modifier_election(election el){
    election e;
    FILE *f;
    FILE *g;
    f = fopen("election.txt","r");
    g = fopen("tmp.txt","a");
    while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF){
        if(strcmp(e.id,el.id) == 0){
            fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s %d\n",el.id,el.nom,el.orientation,el.nomCT,el.cinT,el.nomC1,el.cinC1,el.nomC2,el.cinC2,el.nomC3,el.cinC3,el.nbrVote);
        }
        else{
            fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,e.nbrVote);
        }
    }
    fclose(f);
    fclose(g);
    remove("election.txt");
    rename("tmp.txt","election.txt");
}

/* ----------------------------------------------------------------------------------------- */

int rechercher_election(char id[]){
    election e;
    FILE *f;
    f = fopen("election.txt","r");
    if(f != NULL){
    	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF){
        	if(strcmp(e.id,id) == 0){
       		     return 1;
        	}
    	}
}
    fclose(f);
    return 0;
    

}

















election recherche_election(char id[]){
    election e;
    FILE *f;
    f = fopen("election.txt","r");
    if(f != NULL){
    	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF){
        	if(strcmp(e.id,id) == 0){
       		     return e;
        	}
    	}
}
    fclose(f);
    return;
}












void afficher_electionVote(GtkWidget *liste){
    
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    election e ;
    char nb[20];
    FILE *f;
    store = NULL;
    store = gtk_tree_view_get_model(liste);


    if(store == NULL){
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ID",renderer,"text",EIDS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom LE",renderer,"text",ENOMS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nombre Vote",renderer,"text",ENBVOTESS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    }
	store = gtk_list_store_new(ECOLUMNSS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    
    
    	f = fopen("election.txt","r");
	if(f == NULL){
        	return;
    	}
	else{
        	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF){
			sprintf(nb,"%d",e.nbrVote);
			          		
			gtk_list_store_append(store,&iter);
            		gtk_list_store_set(store,&iter,EIDS,e.id,ENOMS,e.nom,ENBVOTESS,nb,-1);
            		
        	}
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
        	fclose(f);
    	}
    
}
/* ----------------------------------------------------------------------------------------- */

void afficher_election(GtkWidget *liste,char *fname){
    
  GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    election e ;
    char nb[20];
    FILE *f;
    store = NULL;
    store = gtk_tree_view_get_model(liste);


    if(store == NULL){
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ID",renderer,"text",EID,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom LE",renderer,"text",ENOM,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom C1",renderer,"text",ENOMCT,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("N° Cin",renderer,"text",ECINT,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom C2",renderer,"text",ENOMC1,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("N° Cin",renderer,"text",ECINC1,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom C3",renderer,"text",ENOMC2,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("N° Cin",renderer,"text",ECINC2,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom C4",renderer,"text",ENOMC3,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("N° Cin",renderer,"text",ECINC3,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nombre Vote",renderer,"text",ENBVOTES,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    }
	store = gtk_list_store_new(ECOLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    
    
    	f = fopen(fname,"r");
	if(f == NULL){
        	return;
    	}
	else{
        	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF){
			sprintf(nb,"%d",e.nbrVote);
			          		
			gtk_list_store_append(store,&iter);
            		gtk_list_store_set(store,&iter,EID,e.id,ENOM,e.nom,ENOMCT,e.nomCT,ECINT,e.cinT,ENOMC1,e.nomC1,ECINC1,e.cinC1,ENOMC2,e.nomC2,ECINC2,e.cinC2,ENOMC3,e.nomC3,ECINC3,e.cinC3,ENBVOTES,nb,-1);
            		
        	}
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
        	fclose(f);
    	}
    
}

/* ----------------------------------------------------------------------------------------- */

int trierLE(GtkWidget *liste,char *fname){
	election e;
	election data[1000];
    	FILE *f;

	int count = 0; 
   	f = fopen("election.txt","r");

    while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&(e.nbrVote))!=EOF){
     
	    data[count] = e ;
		count++ ; 
	
    }
    fclose(f);

	int i,j;
	election c;
	for(i=0;i<count-1;i++){
	    for(j=i+1;j<count;j++){
		if ( data[i].nbrVote > data[j].nbrVote ) {
		    c = data[i];
		    data[i] = data[j];
		    data[j] = c;
			}
		}
	}
	 
	


	
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
 
    char nb[20];
    store = NULL;
    store = gtk_tree_view_get_model(liste);


    if(store == NULL){
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ID",renderer,"text",EIDSS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom LE",renderer,"text",ENOMSS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom Tete list",renderer,"text",ENOMCTS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("N° Cin",renderer,"text",ECINTS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nombre Vote",renderer,"text",ENBVOTESSS,NULL);
        column = gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


    }
	store = gtk_list_store_new(ECOLUMNSS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    
    	int k = 0;
	while(k < count){	
		sprintf(nb,"%d",data[k].nbrVote);
		          		
		gtk_list_store_append(store,&iter);
    		gtk_list_store_set(store,&iter,EIDSS,data[k].id,ENOMSS,data[k].nom,ENOMCTS,data[k].nomCT,ECINTS,data[k].cinT,ENBVOTESSS,nb,-1);
		k++;

	}

	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
        	
    	

	

	

}


/* ----------------------------------------------------------------------------------------- */

































enum{
	EID,
	ENOM,
	EPRENOM,
	ENATION,
	EGENRE,
	EPARTIEP,
	EPRESSE,
	ESOCIETEC,
	EORG,
	EDATE,	
	ECOLUMNS,
};

/* ------------------------------------------------------------------------------------------ */

void ajouter_observateur(observateur o){
	
	FILE *f;
	f=fopen("observateur.txt","a");

	if(f!=NULL){
	   fprintf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,o.d.j,o.d.m,o.d.a);
	   }
	fclose(f);

}

/* ------------------------------------------------------------------------------------------ */


void supprimer_observateur(char id[]){
	observateur o;

	FILE *f,*g;
	f=fopen("observateur.txt","r");
	g=fopen("tmp.txt","a");

	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF){
	     if(strcmp(id,o.id)!=0){
		fprintf(g,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,o.d.j,o.d.m,o.d.a);
	      } 
	   }

	fclose(f);
	fclose(g);
	remove("observateur.txt");
	rename("tmp.txt","observateur.txt");
}

/* ------------------------------------------------------------------------------------------ */


void modifier_observateur(observateur y){
	observateur o;
	FILE *f,*g;
	f=fopen("observateur.txt","r");
	g=fopen("tmp.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF){
	  if(strcmp(o.id,y.id)==0){

	       fprintf(g,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",y.id,y.nom,y.prenom,y.nationalite,y.genre,y.partie_p,y.presse,y.societe_civ,y.organisationM,y.d.j,y.d.m,y.d.a);

	  }else{
		fprintf(g,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,o.d.j,o.d.m,o.d.a);
	} 
	    
	   }
	fclose(f);
	fclose(g);
	remove("observateur.txt");
	rename("tmp.txt","observateur.txt");
}

/* ------------------------------------------------------------------------------------------ */

void afficher_observateur(GtkWidget *liste){

	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	observateur o ;
	char date[50];
	store=NULL;
	FILE  *f;
	store=gtk_tree_view_get_model(liste);



  	if(store==NULL){
	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes(" Id ",renderer,"text",EID,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",ENOM,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Prénom",renderer,"text",EPRENOM,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Nationalité",renderer,"text",ENATION,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Genre",renderer,"text",EGENRE,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Partie Politique",renderer,"text",EPARTIEP,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Presse",renderer,"text",EPRESSE,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Societé civile",renderer,"text",ESOCIETEC,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	   
	   renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Organisation",renderer,"text",EORG,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer=gtk_cell_renderer_text_new();
	   column=gtk_tree_view_column_new_with_attributes("Date de Naissance",renderer,"text",EDATE,NULL);
	   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   		store=gtk_list_store_new(ECOLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("observateur.txt","r");

     if(f!=NULL)
        {
         while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF){
		sprintf(date,"%d/%d/%d",o.d.j,o.d.m,o.d.a);
           	gtk_list_store_append(store,&iter);
          
	gtk_list_store_set(store,&iter,EID,o.id,ENOM,o.nom,EPRENOM,o.prenom,ENATION,o.nationalite,EGENRE,o.genre,EPRESSE,o.presse,EPARTIEP,o.partie_p,ESOCIETEC,o.societe_civ,EORG,o.organisationM,EDATE,date,-1);
          }
        }
   fclose(f);
   gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
   g_object_unref(store);  
   }
}

/* ------------------------------------------------------------------------------------------ */

int rechercher_observateur(char id[]){
	observateur o ;	
	FILE *f;
	f = fopen("observateur.txt","r");
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF)
		{
			if(strcmp(o.id,id) == 0){
				return 1 ; 
			}

		}
	return 0;
	
}

/* ------------------------------------------------------------------------------------------ */

observateur observateur_data(char id[]){
	observateur o ;	
	FILE *f;
	f = fopen("observateur.txt","r");
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF)
		{
			if(strcmp(o.id,id) == 0){
				return o ; 
			}

		}
	return;
}

/* ------------------------------------------------------------------------------------------ */

int nbTotalObservateur(){

	observateur o ;
	int count = 0 ;	
	FILE *f;
	f = fopen("observateur.txt","r");
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF){
			count ++ ;
	}
	return count;

}

/* ------------------------------------------------------------------------------------------ */

int nbTotalObservateurNationnaux(){

	observateur o ;
	int count = 0 ;	
	FILE *f;
	f = fopen("observateur.txt","r");
	while(fscanf(f,"%s %s %s %s %s %s %s %s %s %d/%d/%d\n",o.id,o.nom,o.prenom,o.nationalite,o.genre,o.partie_p,o.presse,o.societe_civ,o.organisationM,&(o.d.j),&(o.d.m),&(o.d.a))!=EOF){
			if(strcmp(o.nationalite,"Tunisienne") == 0){
				count ++ ;
			}
	}
	return count;

}




