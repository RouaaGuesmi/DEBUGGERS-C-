#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>


int annee;
typedef struct
{
    char id[20];
    char nom[20];
    char orientation[30];
    char nomCT[30];
    char cinT[20];
    char nomC1[30];
    char cinC1[20];
    char nomC2[30];
    char cinC2[20];
    char nomC3[30];
    char cinC3[20];
    int nbrVote ;
}election;



void ajouter(election el);
void supprimer(char id[]);
void modifier_election(election el);
void afficher_election(GtkWidget *liste,char *fname);
void afficher_electionVote(GtkWidget *liste);

int rechercher_election(char id[]);

election recherche_election(char id[]);

int trierLE(GtkWidget *liste,char *fname);







typedef struct
{
	int j;
	int m;
	int a;
}date;

typedef struct
{
	char id[30];
	char nom[30];
	char prenom[30];
	char nationalite[30];
	char genre[30];
	char partie_p[30];
	char presse[30];
	char societe_civ[30];
	char organisationM[30];
	date d;	
}observateur ;

void ajouter_observateur(observateur o);
void supprimer_observateur(char id[]);
void modifier_observateur(observateur o);
void afficher_observateur(GtkWidget *liste);

int rechercher_observateur(char id[]);
observateur observateur_data(char id[]);

int nbTotalObservateur();
int nbTotalObservateurNationnaux() ;


