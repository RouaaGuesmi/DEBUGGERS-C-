#ifndef RECLAMATION_H_INCLUDED
#define RECLAMATION_H_INCLUDED
#include <stdio.h>
#include <gtk/gtk.h>
#include <ctype.h>
/*typedef struct
{
    char id[20]; /*e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&nbrVote*
    char nom[20];
    char orientation[30];
    char nomCT[30];
    char cinT[20];
    char nomC1[30];
    char cinC1[20];
    char nomC2[30];
    char cinC2[20];
    char nomC3[30];
    char cinC3[20];
    int nbrVote ;
}election;*/

typedef struct
{
    char nom [10]; 
    char prenom[10];
    char cin[10];
    int id_rec;
 
}Reclamation;
typedef struct
{
    char nom [20];
    char prenom [20];
    char genre [20];
    int age,cin ;
} personne ;
typedef struct
{
    char nom [20];
    char psw [20];
    char role [20];

} login ;
void ajouter_r(Reclamation r,int choix[],char ch[]);
void afficher(GtkWidget *liste,char ch[]);
void supprimer_r(Reclamation r,char ch[]); 
Reclamation chercher( int id ,char ch[]);
login chercherlogin(char ch[] ,char ch2[]);
int id();
void validation (int choice );
int controlle(char chaine[]);
int controlle1(char chaine[]);
int homme();
int femme();
void modifier (Reclamation r2,char ch2[] ,char ch[],int choix2[]);
int supprimer_1(char ch[],int id);


#endif 
