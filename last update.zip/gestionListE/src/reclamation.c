#include "reclamation.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "reclamation.h"
#include "election.h"
#include <gtk/gtk.h>
enum{
	ECIN,
	ENOM,
	EPRENOM,
	EID,
	COLUMNS,
};
GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;
int controlle1(char chaine[])
{
	int i=0;
	int tr=0;

	for (i=0;i<strlen(chaine);i++){
		if (isalpha(chaine[i]))
			tr=1;
	}
	/*if (tr==1)	
		printf("chaine numerique \n");
	else
		printf("chaine alphabetique \n");*/
    return tr;
}
int controlle(char chaine[])
{
	int i=0;
	int tr=0;

	for (i=0;i<strlen(chaine);i++){
		if (isdigit(chaine[i]))
			tr=1;
	}
	/*if (tr==1)	
		printf("chaine numerique \n");
	else
		printf("chaine alphabetique \n");*/
    return tr;
}
int homme(){
  personne p;
    FILE *f = fopen("personne.txt", "r");
    if(f == NULL){
        return 0;
    }
	else{
        int nb = 0;
        while (fscanf (f,"%d %s %s %s %d\n",&p.cin,p.prenom,p.nom,p.genre,&p.age)!=EOF){
            if(strcmp(p.genre,"homme")==0) nb++;
        }
        fclose(f);
        return nb;
    }
}
int femme(){
  personne p;
    FILE *f = fopen("personne.txt", "r");
    if(f == NULL){
        return 0;
    }else{
        int nb = 0;
        while (fscanf (f,"%d %s %s %s %d\n",&p.cin,p.prenom,p.nom,p.genre,&p.age)!=EOF){
            if(strcmp(p.genre,"femme")==0) nb++;
        }
        fclose(f);
        return nb;
 }
}
int id(){

    FILE *f = fopen("reclamation.txt", "r");
    if(f == NULL){
        return 0;
    }else{
        int nb = 1;
        char c;
        while((c = fgetc(f)) != EOF){
            if(c == '\n') nb++;
        }
        fclose(f);
        return nb;
    }
}

void ajouter_r(Reclamation r,int choix[],char ch[])
{

	strcpy(ch,"");
	if (choix[0]==1)
		strcat(ch,"/nombre_irronee/");
	if (choix[1]==1)
		strcat(ch,"/duree_irronee/");
	if (choix[2]==1)
		strcat(ch,"/donneee_irronee/"); 
	r.id_rec=id();
	FILE * f=fopen("reclamation.txt", "a+");
	if(f!=NULL)
        {
        	fprintf(f,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,ch,r.id_rec);
        	fclose(f);
    	}
	ch[0]="\0";

}
void modifier (Reclamation r2,char ch2[],char ch [],int choix2[]){
    int tr=0;
    Reclamation r;
    strcpy(ch2,"");
    if (choix2[0]==1)
	strcat(ch2,"/nombre_irronee/");
    if (choix2[1]==1)
	strcat(ch2,"/duree_irronee/");
    if (choix2[2]==1)
	strcat(ch2,"/donneee_irronee/");
    FILE *f;
    FILE *tmp ;
    if ((f=fopen("reclamation.txt","r"))==NULL){
        exit(1);
    }
    if ((tmp=fopen("new.txt","w"))==NULL)
        exit(1);
    while (fscanf(f,"%s %s %s %s %d",r.nom,r.prenom,r.cin,ch,&r.id_rec)!=EOF){
        if (strcmp(r.cin,r2.cin)==0){
            tr=1;
            fprintf(tmp,"%s %s %s %s %d\n",r2.nom,r2.prenom,r2.cin,ch2,r.id_rec);
        }
	else{
                fprintf(tmp,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,ch,r.id_rec);

    }
}
    fclose(f);
    fclose(tmp);
    remove("reclamation.txt");
    rename("new.txt","reclamation.txt");
}

Reclamation chercher(int id , char ch[])
{
FILE *f=NULL;
  Reclamation r;
  Reclamation r2;
f = fopen ("reclamation.txt", "r");


 if (f!=NULL){
	while (fscanf (f,"%s %s %s %s %d\n",r2.nom,r2.prenom,r2.cin,ch,&r2.id_rec)!=EOF)
	    	if (r2.id_rec==id)
		{
		strcpy(r.nom,r2.nom);
       	 	strcpy(r.prenom,r2.prenom);
       	 	strcpy(r.cin,r2.cin);
    		}
	    
	fclose(f); 
	} 
 return(r);
 }


int supprimer_1( char ch[],int id)
{
    int tr=0;
    Reclamation r;
    FILE *f;
    FILE *tmp ;
    if ((f=fopen("reclamation.txt","r"))==NULL){
        exit(1);
    }
    if ((tmp=fopen("new.txt","w"))==NULL)
        exit(1);
    while (fscanf(f,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,ch,&r.id_rec)!=EOF){
        if (r.id_rec==id){
            tr=1;
	}
	else{
            fprintf(tmp,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,ch,r.id_rec);
        }

}
    fclose(f);
    fclose(tmp);
    //remove("reclamation.txt");
    //rename("new.txt","reclamation.txt");
    return tr;
}
void validation (int choice ){

if (choice==2){
    remove("reclamation.txt");
    rename("new.txt","reclamation.txt");
	
}
else 
	remove("new.txt");
}

void afficher (GtkWidget *liste, char ch[]){
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter ;
	GtkListStore *store;
	char nom [10]; 
    	char prenom[10];
	char cin[10];
	char id_rec[15];;
	store =NULL;

	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store=NULL){
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id reclamation",renderer,"text",EID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		

	}
	store=gtk_list_store_new (COLUMNS ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("reclamation.txt", "a+") ;
	if (f==NULL){
		return;
	}
	else {
		f=fopen("reclamation.txt", "a+");
		while (fscanf(f,"%s %s %s %s %s\n",nom,prenom,cin,ch,id_rec)!=EOF){
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store ,&iter ,ENOM ,nom ,EPRENOM, prenom ,ECIN,cin,EID,id_rec,-1);
	}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);


}
}

void vider(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom [10]; 
    	char prenom[10];
	char cin[10];
	char id_rec[15];
	store =NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if (store==NULL)

	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id reclamaion",renderer,"text",EID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	}
		
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	gtk_list_store_append (store, &iter);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

 
}




void supprimer_r(Reclamation r,char ch[])
{
	char nom [10]; 
	char prenom[10];
	char cin[10];
	Reclamation r2;
	FILE *f,*g;
	f=fopen("reclamation.txt","r");
	g=fopen("dumb.txt","w");
	if (f==NULL || g==NULL){
		return;
	}
	else {
		while(fscanf(f,"%s %s %s %s %d\n",r2.nom,r2.prenom,r2.cin,ch,&r2.id_rec)!=EOF){
			if (strcmp(r.nom,r2.nom)!=0 || strcmp(r.prenom,r2.prenom)!=0 || strcmp(r.cin,r2.cin)!=0  )
				fprintf(g,"%s %s %s %s %d\n",r2.nom ,r2.prenom,r2.cin,ch,r2.id_rec );
		}

	}
	fclose(f);
	fclose(g);
	remove("reclamation.txt");
	rename("dumb.txt","reclamation.txt");
}

login chercherlogin( char ch[],char ch2[])
{
FILE *f=NULL;
  login l;
  login l2;
  f = fopen ("login.txt", "r");


 if (f!=NULL){
	while (fscanf (f,"%s %s %s\n",l2.nom,l2.psw,l2.role)!=EOF)
	    	if ((strcmp(ch,l2.nom)==0)&&(strcmp(ch2,l2.psw)==0))
			strcpy(l.role,l2.role);
	    
		fclose(f); 
	}
 return(l);
}



