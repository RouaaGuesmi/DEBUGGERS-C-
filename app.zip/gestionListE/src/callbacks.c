#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "election.h"
#include "BV.h"
#include "fonctions.h"
#include "reclamation.h"



int x = 1 ;
int y = 1 ; 

/*Menu--------------------------------------------------------------- */
int choix[3]={0,0,0};
int choix2[3]={0,0,0};
char rec[70];
char rec2[70];
int choice=1;
int choixbv[2]={0,0};
int choicebv=1;
void
on_ajoutBV_clicked                     (GtkWidget        *objet,
                                        gpointer         user_data)
{
	GtkWidget *Windowajout;
	GtkWidget *acceuil;
	Windowajout=lookup_widget(objet,"windowajout");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	Windowajout=create_windowajout();
	gtk_widget_show(Windowajout);

	
}


void
on_modifierBV_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowmodifier;
	GtkWidget *acceuil;

	windowmodifier=lookup_widget(objet,"windowmodifier");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	windowmodifier=create_windowmodifier();
	gtk_widget_show(windowmodifier);
	
	
}


void
on_supprimerBV_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowsupprimer;
	GtkWidget *acceuil;
	windowsupprimer=lookup_widget(objet,"windowsupprimer");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	windowsupprimer=create_windowsupprimer();
	gtk_widget_show(windowsupprimer);
	
}


void
on_afficherBV_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *acceuil;
	GtkWidget *windowafficher;
	GtkWidget *treeviewafichage;
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	windowafficher=lookup_widget(objet,"windowafficher");

	windowafficher=create_windowafficher();
	gtk_widget_show(windowafficher);
	
	
	treeviewafichage=lookup_widget(windowafficher,"treeviewaffichage");
	viderbv(treeviewafichage);
	afficherbv(treeviewafichage);

	
}




void
on_button14_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Windowajout,*acceuil;
	Windowajout=lookup_widget(objet,"windowajout");
	gtk_widget_destroy(Windowajout);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
	
}


void
on_button13_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int x=-1;
	bureau b1,p;
	GtkWidget *input1,*input2,*input3,*input4;
	GtkWidget *output;
	GtkWidget *Windowajout;
	GtkWidget *combobox1;
	GtkWidget *spinbutton;
	int k;
	char vide[2]="";
	GtkWidget *output1 ;
	GtkWidget *output2 ;
	GtkWidget *output3 ;
	GtkWidget *output4 ;
	GtkWidget *output5 ;

	

	char mot2[20]="echec d ajout  ";
	char mot3[20]="(invalide)";
	char mot7[25]="";
	output1=lookup_widget(objet, "label199") ;
	output2=lookup_widget(objet, "label200") ;
	output3=lookup_widget(objet, "label198") ;
	output4=lookup_widget(objet, "label197") ;
	output5=lookup_widget(objet, "label201") ;
	int a,b,c,d;

	Windowajout=lookup_widget(objet,"Windowajout");
	input1=lookup_widget(objet,"IDBV");
	input2=lookup_widget(objet,"capobservateur");
	input3=lookup_widget(objet,"capelecteur");
	input4=lookup_widget(objet,"IDagent");
	combobox1=lookup_widget(objet,"gouv1");
	//gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1));
	spinbutton=lookup_widget(objet,"spinbuttonsalle");
	b1.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton));
	output=lookup_widget(objet,"label195");

	strcpy(b1.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(b1.cap_elec,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(b1.cap_obs,gtk_entry_get_text(GTK_ENTRY(input3)));
	if ((gtk_combo_box_get_active(GTK_COMBO_BOX(combobox1)))!=-1)
		strcpy(b1.b_adr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	strcpy(b1.id_agentb,gtk_entry_get_text(GTK_ENTRY(input4)));
	a=controllebv(b1.id);
	b=controllebv(b1.cap_elec);
	c=controllebv(b1.cap_obs);
	d=controllebv(b1.id_agentb);
	FILE * f=fopen("BV.txt", "r");
	
	if (f!=NULL)
 	{
  		while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
  		{
    			if(strcmp(b1.id,p.id)==0)
				x=1;
  		}
	fclose (f);
  	}
	if (x==1)
	{
	gtk_label_set_text(GTK_LABEL(output),mot2);
	gtk_label_set_text(GTK_LABEL(output1),"id déja utilisé :)");
	}

	else

	{

if ((strcmp(b1.id,vide )!=0) && (strcmp(b1.cap_elec,vide )!=0) && (strcmp(b1.cap_obs,vide )!=0) && (strcmp(b1.b_adr,vide )!=0) && (strcmp(b1.id_agentb,"")!=0) &&(a==1)&&(b==1)&&(d==1)&&(c==1))
	{
		ajouterbv(b1);
		gtk_label_set_text(GTK_LABEL(output),"Bureau De Vote ajouté avec succés :)");
		gtk_label_set_text(GTK_LABEL(output1),vide);
		gtk_label_set_text(GTK_LABEL(output2),vide);
		gtk_label_set_text(GTK_LABEL(output3),vide);
		gtk_label_set_text(GTK_LABEL(output4),vide);
		gtk_label_set_text(GTK_LABEL(output5),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input4),vide);	
		gtk_combo_box_set_active(GTK_COMBO_BOX(combobox1),-1);
		
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output),mot2);
		gtk_label_set_text(GTK_LABEL(output1),mot3);
		gtk_label_set_text(GTK_LABEL(output2),mot3);
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		gtk_label_set_text(GTK_LABEL(output4),mot3);
		gtk_label_set_text(GTK_LABEL(output5),mot3);
		
	}
}
	
}


void
on_button11_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowmodifier,*acceuil;
	windowmodifier=lookup_widget(objet,"windowmodifier");
	gtk_widget_destroy(windowmodifier);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}


void
on_buttonMofier_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{	
	
	char vide[2]="";
	bureau b2;
	GtkWidget *input1,*input2,*input3,*input4;
	GtkWidget *windowmodifier;
	GtkWidget *combobox2;
	GtkWidget *output53;
	GtkWidget *spinsalle;

	windowmodifier=lookup_widget(objet,"windowmodifier");
	input1=lookup_widget(objet,"entry17");
	input2=lookup_widget(objet,"entry18");
	input3=lookup_widget(objet,"entry19");
	input4=lookup_widget(objet,"entry20");
	spinsalle=lookup_widget(objet,"salle1");
	b2.salle=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinsalle));
	combobox2=lookup_widget(objet,"gouv2");
	output53=lookup_widget(objet,"label211");
	

	
	strcpy(b2.id,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(b2.cap_elec,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(b2.cap_obs,gtk_entry_get_text(GTK_ENTRY(input3)));
	if ((gtk_combo_box_get_active(GTK_COMBO_BOX(combobox2)))!=-1)
		strcpy(b2.b_adr,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
	strcpy(b2.id_agentb,gtk_entry_get_text(GTK_ENTRY(input4)));
	if ((strcmp(b2.id,vide )!=0) && (strcmp(b2.cap_elec,vide )!=0) && (strcmp(b2.cap_obs,vide )!=0) && (strcmp(b2.b_adr,vide )!=0) && (strcmp(b2.id_agentb,"")!=0))
	{
		modifierbv(b2);
		gtk_label_set_text(GTK_LABEL(output53),"Bureau De Vote modifié avec succés :)");
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input4),vide);	
		gtk_combo_box_set_active(GTK_COMBO_BOX(combobox2),-1);
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output53),"Echech de modification :( ");
		
	}


}


void
on_buttonsupp2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	bureau b3,p;
	GtkWidget *input,*output;
	char id[20];
	int x=-1;
	
	GtkWidget *windowsupprimer,*windowsuppression;
	
	windowsupprimer=lookup_widget(objet,"windowsupprimer");
	
	input=lookup_widget(objet,"entryIDsup");
	output=lookup_widget(objet,"label218");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	//supprimer(b3,choice);
	FILE * f=fopen("BV.txt", "r");
	
	if (f!=NULL)
 	{
  		while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
  		{
    			if(strcmp(id,p.id)==0)
				x=1;
  		}
	fclose (f);
  	}
	
	if ((strcmp(id,"")!=0)&&(x==1))
	{
		supprimer_bv(id);
		windowsuppression=create_windowsuppression();
		gtk_widget_show(windowsuppression);
		gtk_label_set_text(GTK_LABEL(output),"votre choix eté fait avec succés :)");
		}
	else 
		gtk_label_set_text(GTK_LABEL(output),"id introuvable");

}


void
on_retoursupp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowsupprimer,*acceuil;
	windowsupprimer=lookup_widget(objet,"windowsupprimer");
	gtk_widget_destroy(windowsupprimer);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}


void
on_treeviewafichage_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* id;
	gchar* cap_elec;
	gchar* cap_obs;
	gchar* b_adr;  
	gchar* id_agentb;
	
	bureau b;
	GtkTreeModel *model = gtk_tree_view_get_model (treeview) ;

	if (gtk_tree_model_get_iter(model, &iter, path) )
	{

		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id, 1, &cap_elec,2,&cap_obs,3,&b_adr,4,&id_agentb,-1);
		strcpy(b.id,id);
		strcpy(b.cap_elec,cap_elec) ;
		strcpy(b.cap_obs,cap_obs) ;
		strcpy(b.b_adr,b_adr);
		strcpy(b.id_agentb,id_agentb);
		supprimerbv(b,choicebv);
		afficherbv(treeview);
	}

}
void
on_retour5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *windowafficher,*acceuil;
	windowafficher=lookup_widget(objet,"windowafficher");
	gtk_widget_destroy(windowafficher);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}


void
on_buttonchercher_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char vide[3]="";
	char id[20];
	char salle[20];
	bureau p;
	int x=-1;
	GtkWidget *input,*output1,*output2,*output3,*output4,*output5,*output55;
	GtkWidget *windowmodifier;
		

	windowmodifier=lookup_widget(objet,"windowmodifier");
	input=lookup_widget(objet,"entry17");
	output1=lookup_widget(objet,"entry18");
	output2=lookup_widget(objet,"entry19");
	output3=lookup_widget(objet,"entry20");
	//output4=lookup_widget(objet,"entry13");
	output5=lookup_widget(objet,"gouv2");
	//output55=lookup_widget(objet,"label");
	char gouv[25][50]={" ","ariana","beja","ben_arous","bizerte","gabes","gafsa","jendouba","kairouan","kasserine","kebili","kef","mahdia","manouba","mednine","monastir","nabeul","sfax","sidi_bouzid","siliana","sousse","tataouine","tozeur","tunis","zaghouan"};
	
	int i=0;

	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	FILE * f=fopen("BV.txt", "r");
	
	if (f!=NULL)
 	{
  		while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
  		{
    			if(strcmp(id,p.id)==0)
				x=1;
  		}
	fclose (f);
  	}
	if(x==1)

	{
		bureau p2=chercherbv(id);
		gtk_entry_set_text(GTK_ENTRY(output1),p2.cap_elec);
		gtk_entry_set_text(GTK_ENTRY(output2),p2.cap_obs);
		gtk_entry_set_text(GTK_ENTRY(output3),p2.id_agentb);
		//sprintf(salle,"%d",p2.salle);
		while (i<25 && strcmp(gouv[i],p2.b_adr)!=0){
			i++;
		}
		gtk_combo_box_set_active(GTK_COMBO_BOX(output5),i);//entier
		//gtk_entry_set_text(GTK_ENTRY(output5),p2.b_adr);
		gtk_label_set_text(GTK_LABEL(output55),"Bureau De Vote trouvé :)");
	}	
	else {
		gtk_entry_set_text(GTK_ENTRY(output1),vide);
		gtk_entry_set_text(GTK_ENTRY(output2),vide);
		gtk_entry_set_text(GTK_ENTRY(output3),vide);
		//gtk_entry_set_text(GTK_ENTRY(output4),vide);
		gtk_entry_set_text(GTK_ENTRY(output5),vide);
		//gtk_label_set_text(GTK_LABEL(output55),"Bureau De Vote introuvable :)");
		
}
x=-1;

}	


void
on_confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	bureau b3;
	GtkWidget *output;
	GtkWidget *input,*oui,*non;
	GtkWidget *windowsupprimer;
	GtkWidget *windowsuppression;
	
	windowsuppression=lookup_widget(objet,"windowsuppression");
	//windowsupprimer=lookup_widget(objet,"windowsupprimer");
	oui=lookup_widget(objet,"radiobutton8");
	non=lookup_widget(objet,"radiobutton7");


	if (gtk_toggle_button_get_active(oui)==1)
		choicebv=2;
	if (gtk_toggle_button_get_active(non)==1)
		choicebv=1;
	//output=lookup_widget(objet,"label44");
	validationbv(choicebv);	
	choicebv =1;
	gtk_widget_destroy(windowsuppression);
	

	//gtk_label_set_text(GTK_LABEL(output),"Bureau De Vote supprimé avec succés :)");	
	//gtk_widget_destroy(windowsuppression);
}



void
on_vb_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	char vide1[10];
	char tv[50]="taux de vote blanc ";
	int vote_blanc;
	GtkWidget *output,*tg;
	output =lookup_widget(togglebutton,"labelnbrelec");
	vote_blanc =tvb ();
	int totale=totvot();
	float votb;
	votb=((vote_blanc*100)/totale);
	gcvt(votb, 6, vide1);
	strcat(tv,vide1);
	
	strcat(tv,"%");
	if(gtk_toggle_button_get_active(togglebutton)){
		gtk_label_set_text(GTK_LABEL(output),tv);
	
}	
	else {
	gtk_label_set_text(GTK_LABEL(output),"");
}


}


void
on_nbrelec_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
	choixbv[1]=1;
}
}

void
on_afficherstat_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
char vide1[10];
char tv[50]="taux de vote blanc ";
int vote_blanc;
GtkWidget *output,*tg;
output =lookup_widget(objet,"labelnbrelec");
tg =lookup_widget(objet,"vb");
vote_blanc =tvb ();
int totale=totvot();
float votb;
votb=((vote_blanc*100)/totale);
gcvt(votb, 6, vide1);
strcat(tv,vide1);
	
strcat(tv,"%");

//sprintf(tv,"%d",vote_blanc);    
if (gtk_toggle_button_get_active(tg)==1)
	gtk_label_set_text(GTK_LABEL(output),tv);
if (gtk_toggle_button_get_active(tg)==0)
	gtk_label_set_text(GTK_LABEL(output),"");
}


void
on_retourstat_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *stat;
	GtkWidget *acceuil;
	stat=lookup_widget(objet,"stat");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(stat);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);
}
void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int wa=0;
	int ka=0;
	int ca=0;
	int ba=0;
	int k;
	char vide[2]="";
	GtkWidget*output ;
	GtkWidget*output1 ;
	GtkWidget*output2 ;
	GtkWidget*output3 ;
	GtkWidget*output4 ;
	GtkWidget*output5 ;
	GtkWidget*combobox1 ;
	GtkWidget*output6,*ch1,*ch2,*ch3 ;
	int a,b,c;
	char mot1[30]="ajout avec succes";
	char mot2[20]="echec d ajout  ";
	char mot3[15]="(invalide)";
	char mot4[50]="il faut choisir un choix ";
	char mot5[50]="il faut choisir une liste";
	char mot6[30]="votre id de reclamatin -> ";
	char mot7[25]="";
	output = lookup_widget(objet, "ajoutrecv") ;
	output1 = lookup_widget(objet, "nomrecv") ;
	output2 = lookup_widget(objet, "prenomrecv") ;
	output3 = lookup_widget(objet, "cinrecv") ;
	output4 = lookup_widget(objet, "choixrecv") ;
	output5 = lookup_widget(objet, "listrecv") ;
	output6 = lookup_widget(objet, "coderecv") ;
	combobox1 = lookup_widget(objet, "combobox1") ;
	ch1=lookup_widget(objet,"checkbutton1");
	ch2=lookup_widget(objet,"checkbutton2");
	ch3=lookup_widget(objet,"checkbutton3");

	Reclamation r;
	election e;
	GtkWidget *input1,*input2,*input3;
	GtkWidget *fenetre_ajout;

	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	input1=lookup_widget(objet,"nom");
	input2=lookup_widget(objet,"prenom");
	input3=lookup_widget(objet,"cin");
	k=id();
	sprintf(mot7,"%d",k);
	strcat(mot6,mot7);

	strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
	a=controlle(r.nom);
	b=controlle(r.prenom);
	c=controlle1(r.cin);
	choix[0]=0;
	choix[1]=0;
	choix[2]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==1)
		choix[0]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==0)
		choix[0]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==1)
		choix[1]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==0)
		choix[1]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==1)
		choix[2]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==0)
		choix[2]=0;
	if ((strcmp(r.nom,vide)==0)||(a==1)){
		gtk_label_set_text(GTK_LABEL(output1),mot3);	
		wa=1;
	}
	else {	
		gtk_label_set_text(GTK_LABEL(output1),"");	
		wa=0;
	}
	if ((strcmp(r.prenom,vide)==0)||(b==1)){

		gtk_label_set_text(GTK_LABEL(output2),mot3);
		ba=1;
		}
	else {
		gtk_label_set_text(GTK_LABEL(output2),"");
		ba=0;
		}
	if ((strcmp(r.cin,vide)==0)||(c==1)){
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		ca=1;
	}
	else 	{
		gtk_label_set_text(GTK_LABEL(output3),"");
		ca=0;
	}
	if ((choix[0]==0) && (choix[1]==0) &&(choix[2]==0)){
		gtk_label_set_text(GTK_LABEL(output4),mot4);
		ka=1;
	}
	else 	{
		gtk_label_set_text(GTK_LABEL(output4),"");
		ka=0;
}

	
	if ((wa==0)&&(ba==0) && (ca==0)&&(ka==0))
	{
		ajouter_r(r,choix,rec);
		choix[0]=0;
		choix[1]=0;
		choix[2]=0;
		gtk_label_set_text(GTK_LABEL(output),mot1);
		gtk_label_set_text(GTK_LABEL(output1),vide);
		gtk_label_set_text(GTK_LABEL(output2),vide);
		gtk_label_set_text(GTK_LABEL(output3),vide);
		gtk_label_set_text(GTK_LABEL(output4),vide);
		gtk_label_set_text(GTK_LABEL(output5),vide);
		gtk_label_set_text(GTK_LABEL(output6),mot6);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);
		
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output),mot2);
		/*gtk_label_set_text(GTK_LABEL(output1),mot3);
		gtk_label_set_text(GTK_LABEL(output2),mot3);
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		gtk_label_set_text(GTK_LABEL(output4),mot4);
		gtk_label_set_text(GTK_LABEL(output5),mot5);
		gtk_label_set_text(GTK_LABEL(output5),vide);*/
		
	}
	if( (combobox1)==-1)
		gtk_label_set_text(GTK_LABEL(output5),mot5);
	else 
		gtk_label_set_text(GTK_LABEL(output5),"");
}	

void 
on_afficher_clicked                    (GtkWidget	*objet,
					gpointer 	user_data)
{
	GtkWidget *fenetre_ajout;
	GtkWidget *fenetre_affiche;
	GtkWidget *treeview1;

	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	gtk_widget_destroy(fenetre_ajout);
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");

	fenetre_affiche=create_fenetre_affiche();

	gtk_widget_show(fenetre_affiche);
	treeview1=lookup_widget(fenetre_affiche,"treeviewrec");
	vider(treeview1);
	afficher(treeview1,rec);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* cin;
	gchar* id_rec;
	
	Reclamation r;
	GtkTreeModel *model = gtk_tree_view_get_model (treeview) ;

	if (gtk_tree_model_get_iter(model, &iter, path) ){

		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &nom, 1, &prenom, 2,&cin,3,&id_rec-1);
		/*strcpy(r.nom,nom);
		strcpy(r.prenom,prenom) ;
		strcpy(r.cin,cin) ;
		supprimer(r,rec);*/
		afficher(treeview,rec) ;
	}
}


void
on_retour_clicked                      (GtkWidget      *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_affiche;
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");
	gtk_widget_destroy(fenetre_affiche);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);

}


void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *fenetre_affiche,*w1;
	GtkWidget *treeview1;

	w1=lookup_widget(objet,"fenetre_affiche");
	fenetre_affiche=create_fenetre_affiche();
	gtk_widget_show(fenetre_affiche);
	gtk_widget_hide(w1);
	treeview1=lookup_widget(fenetre_affiche,"treeviewrec");
	vider(treeview1);
	afficher(treeview1,rec);

}


void
on_vider_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_affiche,*w1;
	GtkWidget *treeview1;

	w1=lookup_widget(objet,"fenetre_affiche");
	fenetre_affiche=create_fenetre_affiche();
	gtk_widget_show(fenetre_affiche);
	gtk_widget_hide(w1);
	treeview1=lookup_widget(fenetre_affiche,"treeviewrec");
	rename("reclamation.txt","reserve1.txt");
	rename("reserve","reclamation.txt");
	vider(treeview1);
	afficher(treeview1,rec);
	
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_supprime;
	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	gtk_widget_destroy(fenetre_ajout);
	fenetre_supprime=create_fenetre_supprime();
	gtk_widget_show(fenetre_supprime);


}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_modifier;
	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	gtk_widget_destroy(fenetre_ajout);
	fenetre_modifier=create_fenetre_modifier();
	gtk_widget_show(fenetre_modifier);
}


void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_modifier;
	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	gtk_widget_destroy(fenetre_modifier);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);
}


void
on_enregistrer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int cx[3]={0,0,0};
	char vide[2]="";
	GtkWidget*output ;
	GtkWidget*output1 ;
	GtkWidget*output2 ;
	GtkWidget*output3 ;
	GtkWidget*output4 ;

	char mot1[40]="modification avec succes";
	char mot2[40]="echec de modification !";
	char mot3[15]="(invalide)";
	output = lookup_widget(objet, "lb1") ;
	output1 = lookup_widget(objet, "lb2") ;
	output2 = lookup_widget(objet, "lb3") ;
	output3 = lookup_widget(objet, "lb4") ;
	//output4=lookup_widget(objet,"label140");
	Reclamation r;
	Reclamation new ;
	
	GtkWidget *input1,*input2,*input3,*ch1,*ch2,*ch3;
	GtkWidget *fenetre_modifier;

	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	input1=lookup_widget(objet,"nomrec1");
	input2=lookup_widget(objet,"prenomrec1");
	input3=lookup_widget(objet,"cinrec1");
	ch1=lookup_widget(objet,"checkbutton5");
	ch2=lookup_widget(objet,"checkbutton6");
	ch3=lookup_widget(objet,"checkbutton7");
	strcpy(new.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(new.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(new.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==1)
		choix2[0]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==0)
		choix2[0]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==1)
		choix2[1]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==0)
		choix2[1]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==1)
		choix2[2]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==0)
		choix2[2]=0;
	
	
	
	if ((strcmp(new.nom,vide )!=0) && (strcmp(new.prenom,vide )!=0) && (strcmp(new.cin,vide )!=0) &&((choix2[0]!=0) ||(choix2[1]!=0)||(choix2[2]!=0)))
	{	
		modifier(new,rec2,rec,choix2); 
		choix2[0]=0;
		choix2[1]=0;
		choix2[2]=0;
		gtk_label_set_text(GTK_LABEL(output),vide);
		gtk_label_set_text(GTK_LABEL(output1),vide);
		gtk_label_set_text(GTK_LABEL(output2),vide);
		gtk_label_set_text(GTK_LABEL(output3),mot1);
		//gtk_label_set_text(GTK_LABEL(output4),"");
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output),mot3);
		gtk_label_set_text(GTK_LABEL(output1),mot3);
		gtk_label_set_text(GTK_LABEL(output2),mot3);
		gtk_label_set_text(GTK_LABEL(output3),mot2);
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		
	}
}


void
on_supprimer2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char vide1[]="";
	Reclamation r3;
	Reclamation r;
	int idd;
	GtkWidget *input1,*input2,*input3,*output,*id;
	GtkWidget *fenetre_supprime;
	GtkWidget *fenetre_valide;
	fenetre_supprime=lookup_widget(objet,"fenetre_supprime");
	input1=lookup_widget(objet,"nomrec2");
	input2=lookup_widget(objet,"prenomrec2");
	input3=lookup_widget(objet,"cinrec2");
	output=lookup_widget(objet,"labelrecsup");
	id=lookup_widget(objet,"spinnrec2");
	idd =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id));

	strcpy(r3.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(r3.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(r3.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
	if ((strcmp(r3.nom,"")!=0) &&(strcmp(r3.prenom,"")!=0) &&(strcmp(r3.cin,"")!=0)){
		supprimer_1(rec,idd);
		gtk_label_set_text(GTK_LABEL(output)," choix fait avec succes ");
		fenetre_valide=create_fenetre_valide();
		gtk_widget_show(fenetre_valide);
	}
	else {	
		gtk_label_set_text(GTK_LABEL(output)," il faut tapez ou chercher votre reclamation a supprimer ");

	}
}


void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_supprime,*fenetre_ajout;
	fenetre_supprime=lookup_widget(objet,"fenetre_supprime");
	gtk_widget_destroy(fenetre_supprime);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choix[0]=1;
}
else
	choix[0]=0;
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix[1]=1;
}
else
	choix[1]=0;
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix[2]=1;
}
else
	choix[2]=0;
}


void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix2[0]=1;
}
if ((gtk_toggle_button_get_active(togglebutton))==-1){
choix2[0]=0;
}

}


void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix2[1]=1;
}
if ((gtk_toggle_button_get_active(togglebutton))==-1){
choix2[1]=0;
}

}


void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix2[2]=1;
}
if ((gtk_toggle_button_get_active(togglebutton))==-1){
choix2[2]=0;
}

}


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

	char vide[3]="";
	GtkWidget*input ;
	GtkWidget*input1 ;
	GtkWidget*input2 ;
	GtkWidget*output ;
	GtkWidget*ch1 ;
	GtkWidget*ch2 ;
	GtkWidget*ch3 ;
	GtkWidget* id ;
	GtkWidget*output1 ;
	Reclamation r,r2;
	
	char word[50]="reclamation introuvable ";
	char id_st[10];
	int idd ;
	int x=-1;
	int l=0;
	char ident[25];
	GtkWidget *fenetre_modifier;
	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	id=lookup_widget(objet,"spinrec1");
	output=lookup_widget(objet,"rechrec1");
	input=lookup_widget(objet,"nomrec1");
	input1=lookup_widget(objet,"prenomrec1");
	input2=lookup_widget(objet,"cinrec1");
	//output1 = lookup_widget(objet, "label129") ;
	ch1=lookup_widget(objet,"checkbutton5");
	ch2=lookup_widget(objet,"checkbutton6");
	ch3=lookup_widget(objet,"checkbutton7");
	strcpy(ident,gtk_entry_get_text(GTK_ENTRY(input2)));
	idd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id));
	//gtk_label_set_text(GTK_LABEL(output1),"");
	FILE *f;
	int a=idd;
	f = fopen ("reclamation.txt", "r");
  	if (f!=NULL)
 	{
  		while (fscanf (f,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,rec,&r.id_rec)!=EOF)
  		{
    			if ((idd==r.id_rec)&&(strcmp(ident,r.cin)==0)){
				x=1;
				l=strlen(rec);
			}
  		}
	fclose (f);
  	}
	
	
	if(x==1)

	{
		r2  = chercher(a,rec);
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
	     	gtk_label_set_text(GTK_LABEL(output),"reclamation trouve");
		gtk_entry_set_text(GTK_ENTRY(input),r2.nom);
		gtk_entry_set_text(GTK_ENTRY(input1),r2.prenom);
		//gtk_entry_set_text(GTK_ENTRY(input2),r2.cin);	
		if(l==16)
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
		if(l==31){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
			}
		if(l==33){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
			}
		if(l==48){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
			}
		if(l==15)
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
		if(l==32){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
			}
		if(l==17)
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
}
	else {
		gtk_label_set_text(GTK_LABEL(output),word);
		gtk_entry_set_text(GTK_ENTRY(input),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		//gtk_entry_set_text(GTK_ENTRY(input2),vide);
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
}
x=-1;

}	
void
on_rechercher2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int idd;
	int x=-1;
	char vide1[20]="";
	Reclamation r3;
	Reclamation r;
	GtkWidget *input,*input1,*input2,*id,*output;
	GtkWidget *fenetre_supprime;	
	GtkWidget*ch1 ;
	GtkWidget*ch2 ;
	GtkWidget*ch3 ;
	fenetre_supprime=lookup_widget(objet,"fenetre_supprime");
	input=lookup_widget(objet,"nomrec2");
	input1=lookup_widget(objet,"prenomrec2");
	id=lookup_widget(objet,"spinnrec2");
	input2=lookup_widget(objet,"cinrec2");
	idd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id));
	output=lookup_widget(objet,"rechrec2");
	FILE *f;
	int tmp=idd;
	int a=idd;
	f = fopen ("reclamation.txt", "r");
  	if (f!=NULL)
 	{
  		while (fscanf (f,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,rec,&r.id_rec)!=EOF)
  		{
    			if (idd==r.id_rec)
				x=1;
  		}
     		fclose (f);
  	}
	if(x==1)

	{
	    	Reclamation r2  = chercher(a,rec);
	     	gtk_label_set_text(GTK_LABEL(output),"reclamation trouve");
		gtk_entry_set_text(GTK_ENTRY(input),r2.nom);
		gtk_entry_set_text(GTK_ENTRY(input1),r2.prenom);
		gtk_entry_set_text(GTK_ENTRY(input2),r2.cin);	
	}
	else {	
			gtk_label_set_text(GTK_LABEL(output),"reclamation introuvable");
			gtk_entry_set_text(GTK_ENTRY(input),vide1);
			gtk_entry_set_text(GTK_ENTRY(input1),vide1);
			gtk_entry_set_text(GTK_ENTRY(input2),vide1);	
}
}

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choice=1;
}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choice=2;
}
}


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_supprime,*fenetre_valide,*ch1,*ch2;
	fenetre_valide=lookup_widget(objet,"fenetre_valide");
	ch1=lookup_widget(objet,"checkbutton1");
	ch2=lookup_widget(objet,"checkbutton2");
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==1)
		choice=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==1)
		choice=2;
	validation (choice);
	choice=1;
	gtk_widget_destroy(fenetre_valide);
	
}


void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_affiche,*fenetre_stat;
	GtkWidget *treeview1;
	fenetre_stat=lookup_widget(objet,"fenetre_stat");
	gtk_widget_destroy(fenetre_stat);
	fenetre_affiche=create_fenetre_affiche();
	gtk_widget_show(fenetre_affiche);
	treeview1=lookup_widget(fenetre_affiche,"treeviewrec");
	vider(treeview1);
	afficher(treeview1,rec);
}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char word1[50]="nombre de reclamation totale : ";
	char word2[50]="taux de participation homme  : ";
	char word3[50]="taux de participation femme  : ";
	char vide1[3];
	char vide2[3];
	char vide3[3];
	GtkWidget*output1 ;
	GtkWidget*output2 ;
	GtkWidget*output3 ;
	GtkWidget*output4 ;
	GtkWidget *fenetre_stat;

	fenetre_stat=lookup_widget(objet,"fenetre_stat");
	output1=lookup_widget(objet,"rectot");
	output2=lookup_widget(objet,"hommestat");
	output3=lookup_widget(objet,"femmestat");
	output4=lookup_widget(objet,"label174");
	int l,m,n;
	l=homme();
	m=femme();
	n=id();
	n=n-1;
	int tot=l+m;	
	float f,d;
	f=((l*100)/tot);
	d=((m*100)/tot);
	gcvt(f, 6, vide1);
        gcvt(d, 6, vide2);
	sprintf(vide3,"%d",n);
	strcat(word1,vide3);
	strcat(word2,vide1);
	strcat(word3,vide2);
	strcat(word2,"%");
	strcat(word3,"%");
	gtk_label_set_text(GTK_LABEL(output1),word1);
	gtk_label_set_text(GTK_LABEL(output2),word2);
	gtk_label_set_text(GTK_LABEL(output3),word3);
	gtk_label_set_text(GTK_LABEL(output4),"5 reclamation par cette liste ");


}


void
on_stat_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_affiche,*fenetre_stat;
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");
	gtk_widget_destroy(fenetre_affiche);
	fenetre_stat=create_fenetre_stat();
	gtk_widget_show(fenetre_stat);
	
}


void
on_button5_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget*combobox1 ;
combobox1 = lookup_widget(objet, "combobox5") ;
election e;
int i;
for (i=0;i<10;i++){
gtk_combo_box_remove_text(GTK_COMBO_BOX(combobox1),i);

}
gtk_combo_box_remove_text(GTK_COMBO_BOX(combobox1),0);
char walaa[50];
   FILE *f = fopen("election.txt", "r");
    if(f == NULL){
        return 0;
    }
else{
    
        while (fscanf (f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&e.nbrVote)!=EOF){
		gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1),(e.nom));
        }
}
       fclose(f);

}

/*
void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

}*/
void
on_toAffLE_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"menu_liste_electorale");
	window2 = create_afficher_liste_electorale ();
  	gtk_widget_show (window2);

}


void
on_toAddLE_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"menu_liste_electorale");
	window2 = create_ajout_liste ();
  	gtk_widget_show (window2);

}


void
on_toModLE_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"menu_liste_electorale");
	window2 = create_modifier_liste ();
  	gtk_widget_show (window2);

}


void
on_toVote_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"menu_liste_electorale");
	window2 = create_vote();
  	gtk_widget_show (window2);

}


void
on_toStats_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	window1 = create_statsobs ();
  	gtk_widget_show (window1);

}

/*Ajout--------------------------------------------------------------------------*/
void
on_radiobuttonAG_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		x=1;
	}
}


void
on_radiobuttonAC_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		x=2;
	}
}


void
on_radiobuttonAD_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		x=3;
	}
}


void
on_annuler_ajout_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *nomLE, *idLE , *nomCT , *cinCT , *nomC1 , *cinC1 , *nomC2 ,*cinC2 ,*nomC3 , *cinC3 , *output;
	
	char message[200];
	strcpy(message,"");


	election e;

	idLE=lookup_widget(objet,"idLE");
	nomLE=lookup_widget(objet,"nomLE");

	nomCT=lookup_widget(objet,"nomCT");
	cinCT=lookup_widget(objet,"cinT");

	nomC1=lookup_widget(objet,"nomC1");
	cinC1=lookup_widget(objet,"cinC1");

	nomC2=lookup_widget(objet,"nomC2");
	cinC2=lookup_widget(objet,"cinC2");

	nomC3=lookup_widget(objet,"nomC3");
	cinC3=lookup_widget(objet,"cinC3");

	output = lookup_widget(objet,"outputLE");



	gtk_entry_set_text(GTK_ENTRY(idLE),message);	
	gtk_entry_set_text(GTK_ENTRY(nomLE),message);	


	gtk_entry_set_text(GTK_ENTRY(nomCT),message);
	gtk_entry_set_text(GTK_ENTRY(cinCT),message);

	gtk_entry_set_text(GTK_ENTRY(nomC1),message);
	gtk_entry_set_text(GTK_ENTRY(cinC1),message);

	gtk_entry_set_text(GTK_ENTRY(nomC2),message);
	gtk_entry_set_text(GTK_ENTRY(cinC2),message);

	gtk_entry_set_text(GTK_ENTRY(nomC3),message);	
	gtk_entry_set_text(GTK_ENTRY(cinC3),message);

	gtk_label_set_text(GTK_LABEL(output),message);
}


void
on_ajouterLE_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *nomLE, *idLE , *nomCT , *cinCT , *nomC1 , *cinC1 , *nomC2 ,*cinC2 ,*nomC3 , *cinC3 , *output;
	
	char message[200];


	election e;

	idLE=lookup_widget(objet,"idLE");
	nomLE=lookup_widget(objet,"nomLE");

	nomCT=lookup_widget(objet,"nomCT");
	cinCT=lookup_widget(objet,"cinT");

	nomC1=lookup_widget(objet,"nomC1");
	cinC1=lookup_widget(objet,"cinC1");

	nomC2=lookup_widget(objet,"nomC2");
	cinC2=lookup_widget(objet,"cinC2");

	nomC3=lookup_widget(objet,"nomC3");
	cinC3=lookup_widget(objet,"cinC3");





	output = lookup_widget(objet,"outputLE");



	strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(idLE)));
	strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nomLE)));

	strcpy(e.nomCT,gtk_entry_get_text(GTK_ENTRY(nomCT)));
	strcpy(e.cinT,gtk_entry_get_text(GTK_ENTRY(cinCT)));

	strcpy(e.nomC1,gtk_entry_get_text(GTK_ENTRY(nomC1)));
	strcpy(e.cinC1,gtk_entry_get_text(GTK_ENTRY(cinC1)));

	strcpy(e.nomC2,gtk_entry_get_text(GTK_ENTRY(nomC2)));
	strcpy(e.cinC2,gtk_entry_get_text(GTK_ENTRY(cinC2)));

	strcpy(e.nomC3,gtk_entry_get_text(GTK_ENTRY(nomC3)));
	strcpy(e.cinC3,gtk_entry_get_text(GTK_ENTRY(cinC3)));



	if(x==1){
		strcpy(e.orientation,"gauche");	
	}
	else if(x == 2){
		strcpy(e.orientation,"center");
	}
	else{
		strcpy(e.orientation,"droite");
	}

	e.nbrVote = 0 ; 

	sprintf(message,"Votre ajout a été effectué avec succés ! ");
	gtk_label_set_text(GTK_LABEL(output),message);
	ajouter(e);
	
}

/* Modifier/Supprimer---------------------------------------------------------------------------------------------- */

void
on_consulterLE_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *nomLE , *nomCT , *cinCT , *nomC1 , *cinC1 , *nomC2 ,*cinC2 ,*nomC3 , *cinC3 ;
	GtkWidget *idLE , *output;
	char message[200];
	char id[20];

	idLE = lookup_widget(objet,"idLEE");
	
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(idLE)));
	output = lookup_widget(objet,"outputLEE");	
	

	if(!rechercher_election(id)){
		sprintf(message,"ID NON EXISTANT\n");
		
    		gtk_label_set_text(GTK_LABEL(output),message);	
	}
	else{
		election e;

		strcpy(e.id,id);		
		strcpy(e.nom,recherche_election(id).nom);
		strcpy(e.orientation,recherche_election(id).orientation);

		strcpy(e.nomCT,recherche_election(id).nomCT);
		strcpy(e.cinT,recherche_election(id).cinT);

		strcpy(e.nomC1,recherche_election(id).nomC1);
		strcpy(e.cinC1,recherche_election(id).cinC1);

		strcpy(e.nomC2,recherche_election(id).nomC2);
		strcpy(e.cinC2,recherche_election(id).cinC2);

		strcpy(e.nomC3,recherche_election(id).nomC3);
		strcpy(e.cinC3,recherche_election(id).cinC3);

		


					
		sprintf(message,"Tapez vos nouveau donnée puis cliquez sur\n\tenregistrer les modifications\n");
		gtk_label_set_text(GTK_LABEL(output),message);	
		

		nomLE=lookup_widget(objet,"nomLEE");
    		gtk_entry_set_text(GTK_ENTRY(nomLE),e.nom);

		nomCT=lookup_widget(objet,"nomCTE");
		gtk_entry_set_text(GTK_ENTRY(nomCT),e.nomCT);

		cinCT=lookup_widget(objet,"cinTE");
		gtk_entry_set_text(GTK_ENTRY(cinCT),e.cinT);

		nomC1=lookup_widget(objet,"nomCE1");
		gtk_entry_set_text(GTK_ENTRY(nomC1),e.nomC1);

		cinC1=lookup_widget(objet,"cinCE1");
		gtk_entry_set_text(GTK_ENTRY(cinC1),e.cinC1);

		nomC2=lookup_widget(objet,"nomCE2");
		gtk_entry_set_text(GTK_ENTRY(nomC2),e.nomC2);

		cinC2=lookup_widget(objet,"cinCE2");
		gtk_entry_set_text(GTK_ENTRY(cinC2),e.cinC2);


		nomC3=lookup_widget(objet,"nomCE3");
		gtk_entry_set_text(GTK_ENTRY(nomC3),e.nomC3);

		cinC3=lookup_widget(objet,"cinCE3");
		gtk_entry_set_text(GTK_ENTRY(cinC3),e.cinC3);

		
	}
}





void
on_radiobuttonGE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		y=1;
	}
}


void
on_radiobuttonCE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		y=2;
	}
}


void
on_radiobuttonDE_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		y=3;
	}
}


void
on_supprimerLE_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *idLE , *output;
	char message[200];
	char id[20];

	idLE = lookup_widget(objet,"idLEE");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(idLE)));


	output = lookup_widget(objet,"outputLEE");

	if(rechercher_election(id)){
		sprintf(message,"Votre suppression a été effectué avec succés ! ");
	gtk_label_set_text(GTK_LABEL(output),message);
		
	supprimer(id);
	}
	else{
		sprintf(message,"Identifiant non existant ! ");
		gtk_label_set_text(GTK_LABEL(output),message);
	
	}
		
		
}


void
on_saveChangesLE_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *nomLE , *nomCT , *cinCT , *nomC1 , *cinC1 , *nomC2 ,*cinC2 ,*nomC3 , *cinC3 ;
	GtkWidget *idLE , *output;
	char message[200];
	char id[20];
	election e;

	idLE = lookup_widget(objet,"idLEE");
	
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(idLE)));
	output = lookup_widget(objet,"outputLEE");

	if(rechercher_election(id)){
		nomLE=lookup_widget(objet,"nomLEE");
		nomCT=lookup_widget(objet,"nomCTE");
		cinCT=lookup_widget(objet,"cinTE");

		nomC1=lookup_widget(objet,"nomCE1");
		cinC1=lookup_widget(objet,"cinCE1");

		nomC2=lookup_widget(objet,"nomCE2");
		cinC2=lookup_widget(objet,"cinCE2");

		nomC3=lookup_widget(objet,"nomCE3");
		cinC3=lookup_widget(objet,"cinCE3");

		strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(idLE)));
		strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nomLE)));

		strcpy(e.nomCT,gtk_entry_get_text(GTK_ENTRY(nomCT)));
		strcpy(e.cinT,gtk_entry_get_text(GTK_ENTRY(cinCT)));

		strcpy(e.nomC1,gtk_entry_get_text(GTK_ENTRY(nomC1)));
		strcpy(e.cinC1,gtk_entry_get_text(GTK_ENTRY(cinC1)));

		strcpy(e.nomC2,gtk_entry_get_text(GTK_ENTRY(nomC2)));
		strcpy(e.cinC2,gtk_entry_get_text(GTK_ENTRY(cinC2)));

		strcpy(e.nomC3,gtk_entry_get_text(GTK_ENTRY(nomC3)));
		strcpy(e.cinC3,gtk_entry_get_text(GTK_ENTRY(cinC3)));



		if(y==1){
			strcpy(e.orientation,"gauche");	
		}
		else if(y == 2){
			strcpy(e.orientation,"center");
		}
		else{
			strcpy(e.orientation,"droite");
		}

		e.nbrVote = recherche_election(id).nbrVote ; 

		sprintf(message,"Votre modification a été effectué avec succés ! ");
		gtk_label_set_text(GTK_LABEL(output),message);
		modifier_election(e);
		
	}
	else{
		sprintf(message,"Identifiant non existant ! ");
		gtk_label_set_text(GTK_LABEL(output),message);
	
	}

	
}

/*Affichage------------------------------------------------------------------------------------------------------------------ */

void
on_afficherLE_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *treeview;	
	treeview = lookup_widget(objet,"treeviewLE");
		
	afficher_election(treeview,"election.txt");
}



/*Vote ------------------------------------------------------------------------------------------------------------------------------------------- */



void
on_voter_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *idLE , *output ; 
	char id[30];
	char message[100] ;  

	idLE = lookup_widget(objet,"idVote");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(idLE)));
	
	output = lookup_widget(objet,"outputVote");

	if(rechercher_election(id)){
		election e;

		strcpy(e.id,id);		
		strcpy(e.nom,recherche_election(id).nom);
		strcpy(e.orientation,recherche_election(id).orientation);

		strcpy(e.nomCT,recherche_election(id).nomCT);
		strcpy(e.cinT,recherche_election(id).cinT);

		strcpy(e.nomC1,recherche_election(id).nomC1);
		strcpy(e.cinC1,recherche_election(id).cinC1);

		strcpy(e.nomC2,recherche_election(id).nomC2);
		strcpy(e.cinC2,recherche_election(id).cinC2);

		strcpy(e.nomC3,recherche_election(id).nomC3);
		strcpy(e.cinC3,recherche_election(id).cinC3);

		e.nbrVote = recherche_election(id).nbrVote + 1 ; 
		modifier_election(e);
		sprintf(message,"Vote ajouté avec succés  ! ");
		gtk_label_set_text(GTK_LABEL(output),message);
	}
	else{
		sprintf(message,"Identifiant non existant ! ");
		gtk_label_set_text(GTK_LABEL(output),message);
	}
}


void
on_refreshTreeView_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview;	
	treeview = lookup_widget(objet,"treeviewVote");
		
	afficher_election(treeview,"election.txt");
}


void
on_refreshStat1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview;	
	treeview = lookup_widget(objet,"treeviewStat1");
		
	afficher_electionVote(treeview);
}


void
on_refreshStat2_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview;	
	treeview = lookup_widget(objet,"treeviewStat2");
		trierLE(treeview,"election.txt");
	

}
void
on_checkbuttonajout_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
/*if(gtk_toggle_button_get_active(togglebutton)){
		genreM = 1;
	}*/
}


void
on_checkbuttonmodif_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


/*___________________________________________________________________________________*/


int genre = 1 ; // 1 : Homme | 2 : Femme
int genreM = 1 ;

void
on_ajouterobsmenu_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(window1);

	window2 = create_ajouterobs ();
	gtk_widget_show(window2 );
}


void
on_affichageobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(window1);

	window2 = create_affichageobs ();
	gtk_widget_show(window2 );
}


void
on_radioHA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genre = 1;
	}
}


void
on_radioFA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genre = 2;
	}
}


void
on_retourAjoutObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"ajouterobs");
	gtk_widget_destroy(window1);

	window2 = create_menuobservateur ();
	gtk_widget_show(window2 );
}


void
on_retourAffichageObs_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"affichageobs");
	gtk_widget_destroy(window1);

	window2 = create_menuobservateur ();
	gtk_widget_show(window2 );
}


void
on_confirmAjoutObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id , *nom , *prenom , *nation , *partieP , *presse , *societeC , *organisationM , *spinJ , *spinM , *spinA , *output ;

	observateur o ;

	id = lookup_widget(objet,"idobs");
	strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(id)));

	nom = lookup_widget(objet,"nomobs");
	strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

	prenom = lookup_widget(objet,"prenomobs");
	strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	nation = lookup_widget(objet,"comboboxobs");
	strcpy(o.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nation)));

	//if(genre == 1){
	//	strcpy(o.genre,"Homme");
	//}else{
		strcpy(o.genre,"Femme");
	//}

	partieP = lookup_widget(objet,"politiqueobs");
	strcpy(o.partie_p,gtk_combo_box_get_active_text(GTK_COMBO_BOX(partieP)));

	presse = lookup_widget(objet,"presseobs");
	strcpy(o.presse,gtk_entry_get_text(GTK_ENTRY(presse)));

	societeC = lookup_widget(objet,"civileobs");
	strcpy(o.societe_civ,gtk_entry_get_text(GTK_ENTRY(societeC)));

	organisationM = lookup_widget(objet,"orgobs");
	strcpy(o.organisationM,gtk_entry_get_text(GTK_ENTRY(organisationM)));
	

	spinJ = lookup_widget(objet,"spinAJ");
	spinM = lookup_widget(objet,"spinAM");
	spinA = lookup_widget(objet,"spinAA");


	o.d.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinJ));
	o.d.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinM));
	o.d.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinA));


	output = lookup_widget(objet,"outputajoutobs");
	char message[200];


	if(rechercher_observateur(o.id) == 0){
		sprintf(message,"Votre ajout a été effectué avec succés !");
		gtk_label_set_text(GTK_LABEL(output),message);
		ajouter_observateur(o);
	}else{
		sprintf(message,"ID Déja existant");
		gtk_label_set_text(GTK_LABEL(output),message);
	}

	
}


void
on_treeviewObs_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}
void
on_afficherObs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview ;
	treeview = lookup_widget(objet,"obstree");////////////////
	afficher_observateur(treeview);
	
}


void
on_afficherStats_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *a1 , *a2 , *a3 , *a4;

	

	
	char text1[20],text2[20],text3[20],text4[20];


	a1 = lookup_widget(objet,"a1");
	int nbTotal = nbTotalObservateur();
	sprintf(text1,"%d",nbTotal);
	gtk_label_set_text(GTK_LABEL(a1),text1);

	
	a2 = lookup_widget(objet,"a2");
	int nbNationnaux = nbTotalObservateurNationnaux(); 
	sprintf(text2,"%d",nbNationnaux);
	gtk_label_set_text(GTK_LABEL(a2),text2);


	a3 = lookup_widget(objet,"a3");
	int nbEtranger = nbTotal - nbNationnaux ; 
	sprintf(text3,"%d",nbEtranger);
	gtk_label_set_text(GTK_LABEL(a3),text3);



	a4 = lookup_widget(objet,"a4");
	float taux = (nbEtranger*100)/nbTotal;
	int percent = 37 ;
	sprintf(text4,"%.2f %c",taux,percent);
	gtk_label_set_text(GTK_LABEL(a4),text4); 
	
}


void
on_menustatsobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(window1);

	window2 = create_statsobs();
	gtk_widget_show(window2 );
}


void
on_retourStats_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"statsobs");
	gtk_widget_destroy(window1);

	window2 = create_menuobservateur ();
	gtk_widget_show(window2 );
}


void
on_rechercherObs_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *idObs , *output;
 
	idObs = lookup_widget(objet,"idobsM");
	output = lookup_widget(objet,"outputEdit");
	
	observateur o; 
	char message[200];


	strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(idObs)));

	if(rechercher_observateur(o.id) == 1){
		sprintf(message,"Tapez vos nouveaux données puis\n\t sauvegarder les modifications");
		gtk_label_set_text(GTK_LABEL(output),message);

		GtkWidget  *nom , *prenom , *nation , *partieP , *presse , *societeC , *organisationM , *spinJ , *spinM , *spinA ;


		nom = lookup_widget(objet,"nomobsM");
		gtk_entry_set_text(GTK_ENTRY(nom),observateur_data(o.id).nom);

		prenom = lookup_widget(objet,"prenomobsM");
		gtk_entry_set_text(GTK_ENTRY(prenom),observateur_data(o.id).prenom);

		nation = lookup_widget(objet,"comboboxobsM");
		int comboValue = 0 ;
		char oldNation[40];
		strcpy(oldNation,observateur_data(o.id).nationalite);
		if(strcmp(oldNation,"Etrangere") == 0){
			comboValue = 1;
		}
		gtk_combo_box_set_active(nation,comboValue);



		partieP = lookup_widget(objet,"politiqueobsM");
		char oldPartie_p[40];
		strcpy(oldPartie_p,observateur_data(o.id).partie_p);

		comboValue = 0 ;
		if(strcmp(oldPartie_p,"Center") == 0){
			comboValue = 1;
		}else if(strcmp(oldPartie_p,"Gauche") == 0){
			comboValue = 2;
		}

		gtk_combo_box_set_active(partieP,comboValue);


		presse = lookup_widget(objet,"presseobsM");
		gtk_entry_set_text(GTK_ENTRY(presse),observateur_data(o.id).presse);

		societeC = lookup_widget(objet,"civileobsM");
		gtk_entry_set_text(GTK_ENTRY(societeC),observateur_data(o.id).societe_civ);

		organisationM = lookup_widget(objet,"organisationobsM");
		gtk_entry_set_text(GTK_ENTRY(organisationM),observateur_data(o.id).organisationM);


		

		spinJ = lookup_widget(objet,"spinMJ");
		spinM = lookup_widget(objet,"spinMM");
		spinA = lookup_widget(objet,"spinMA");

		gtk_spin_button_set_value(spinJ,observateur_data(o.id).d.j);
		gtk_spin_button_set_value(spinM,observateur_data(o.id).d.m);
		gtk_spin_button_set_value(spinA,observateur_data(o.id).d.a);


	}else{
		sprintf(message,"ID Non existant !");
		gtk_label_set_text(GTK_LABEL(output),message);
	}
}


void
on_radioHM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genreM = 1;
	}
}


void
on_radioFM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genreM = 2;
	}
}


void
on_enregistrerModObs_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id , *nom , *prenom , *nation , *partieP , *presse , *societeC , *organisationM , *spinJ , *spinM , *spinA , *output ;

	observateur o ;

	id = lookup_widget(objet,"idobsM");
	strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(id)));

	nom = lookup_widget(objet,"nomobsM");
	strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

	prenom = lookup_widget(objet,"prenomobsM");
	strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	nation = lookup_widget(objet,"comboboxobsM");
	strcpy(o.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nation)));

	if(genreM == 1){
		strcpy(o.genre,"Homme");
	}else{
		strcpy(o.genre,"Femme");
	}

	partieP = lookup_widget(objet,"politiqueobsM");
	strcpy(o.partie_p,gtk_combo_box_get_active_text(GTK_COMBO_BOX(partieP)));

	presse = lookup_widget(objet,"presseobsM");
	strcpy(o.presse,gtk_entry_get_text(GTK_ENTRY(presse)));

	societeC = lookup_widget(objet,"civileobsM");
	strcpy(o.societe_civ,gtk_entry_get_text(GTK_ENTRY(societeC)));

	organisationM = lookup_widget(objet,"organisationobsM");
	strcpy(o.organisationM,gtk_entry_get_text(GTK_ENTRY(organisationM)));

	

	spinJ = lookup_widget(objet,"spinMJ");
	spinM = lookup_widget(objet,"spinMM");
	spinA = lookup_widget(objet,"spinMA");


	o.d.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinJ));
	o.d.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinM));
	o.d.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinA));


	output = lookup_widget(objet,"outputEdit");
	char message[200];

	if(rechercher_observateur(o.id) == 1){
		sprintf(message,"Votre  observateur a été modifié avec succés !");
		gtk_label_set_text(GTK_LABEL(output),message);
		modifier_observateur(o);
	}else{
		sprintf(message,"ID Non existant");
		gtk_label_set_text(GTK_LABEL(output),message);
	}

}


void
on_retourModifObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"modifObs");
	gtk_widget_destroy(window1);

	window2 = create_affichageobs ();
	gtk_widget_show(window2 );
}


void
on_modifierParmObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"affichageobs");
	gtk_widget_destroy(window1);

	window2 = create_modifObs ();
	gtk_widget_show(window2 );
}


void
on_supprimerObservateur_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id , *output ;

	char idObs[30] ; 
	char message[200];

	id = lookup_widget(objet,"idobsM");
	strcpy(idObs,gtk_entry_get_text(GTK_ENTRY(id)));

	output = lookup_widget(objet,"outputEdit");

	if(rechercher_observateur(idObs) == 1){
		sprintf(message,"Votre  observateur a été Supprimer avec succés !");
		gtk_label_set_text(GTK_LABEL(output),message);
		supprimer_observateur(idObs);
	}else{
		sprintf(message,"ID Non existant");
		gtk_label_set_text(GTK_LABEL(output),message);
	}
	

}


void
on_confirm_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}





void
on_reclamation_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *menuobservateur;
	GtkWidget *fenetre_ajout;

	menuobservateur=lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(menuobservateur);
	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");

	fenetre_ajout=create_fenetre_ajout();

	gtk_widget_show(fenetre_ajout);
}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choicebv=1;
}
}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choicebv=1;
}
}


void
on_statbv_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *stat;
	GtkWidget *acceuil;
	stat=lookup_widget(objet,"stat");

	
	acceuil=lookup_widget(objet,"acceuil");
	gtk_widget_destroy(acceuil);
	stat=create_stat();
	gtk_widget_show(stat);
}


void
on_retourbv_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *login;
GtkWidget *acceuil;
GtkWidget *fenetre_ajout;
login=lookup_widget(objet,"windowlogin");	
acceuil=lookup_widget(objet,"acceuil");
gtk_widget_destroy(acceuil);
login=create_windowlogin();
gtk_widget_show(login);
}


void
on_buttonlogin_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
login l;
login l2;
char nom1[60];
char psw1[25];
int c;
GtkWidget *login;
GtkWidget *acceuil;
GtkWidget *fenetre_ajout;
GtkWidget *menu_liste_electorale;
GtkWidget *menuobservateur;
GtkWidget *fenetre1;
login=lookup_widget(objet,"windowlogin");	
/*fenetre1=lookup_widget(objet,"fenetre1");
acceuil=lookup_widget(objet,"acceuil");
fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
menu_liste_electorale=lookup_widget(objet,"menu_liste_electorale");
menuobservateur=lookup_widget(objet,"menuobservateur");*/
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *output;
output=lookup_widget(objet,"walaa");
input1=lookup_widget(objet,"loginname");
input2=lookup_widget(objet,"loginpsw");

strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(psw1,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(l.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(l.psw,gtk_entry_get_text(GTK_ENTRY(input2)));
	l2 = chercherlogin(l.nom,l.psw);

	if (strcmp(l2.role,"bv")==0){
	gtk_widget_destroy(login);
	acceuil=create_acceuil();
	gtk_widget_show(acceuil);}
	if (strcmp(l2.role,"obs")==0){
	gtk_widget_destroy(login);
	menuobservateur=create_menuobservateur();
	gtk_widget_show(menuobservateur);}
	
	if (strcmp(l2.role,"liste")==0){
	gtk_widget_destroy(login);
	menu_liste_electorale=create_menu_liste_electorale();
	gtk_widget_show(menu_liste_electorale);}
		
	if (strcmp(l2.role,"reclamation")==0){
	gtk_widget_destroy(login);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);}


	if (strcmp(l2.role,"user")==0){
	gtk_widget_destroy(login);
	fenetre1=create_fenetre1();
	gtk_widget_show(fenetre1);}
	else 
		if(strcmp(nom1,"")==0 && strcmp(psw1,"")==0)
	    		gtk_label_set_text(GTK_LABEL(output),"tapez l'adresse ou mot de passe ! ");
		else 
			if(strcmp(l2.role,"reclamation")!=0)
		    		gtk_label_set_text(GTK_LABEL(output),"incorrect");

}




void
on_listlog_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *login;
	GtkWidget *acceuil;
	login=lookup_widget(objet,"windowlogin");

	
	acceuil=lookup_widget(objet,"menu_liste_electorale");
	gtk_widget_destroy(acceuil);
	login=create_windowlogin();
	gtk_widget_show(login);
}

int za=1;
int xa=1; 
int ya=0;
void
on_button_gestion_des_utilisateurs_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1 ;
GtkWidget *treeview1 ;
w=lookup_widget(objet,"espace_adminstrateur");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_utilisateur(treeview1);


}


void
on_comboboxentry10_changed             (GtkComboBox     *combobox,
                                        gpointer         user_data)
{

}


void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*ajouter_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
 ajouter_un_utilisateur = create_ajouter_un_utilisateur ();
  gtk_widget_show (ajouter_un_utilisateur);
}


void
on_button_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*modifier_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
 modifier_un_utilisateur = create_modifier_un_utilisateur ();
  gtk_widget_show (modifier_un_utilisateur);
}


void
on_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*supprimer_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
supprimer_un_utilisateur = create_supprimer_un_utilisateur ();
  gtk_widget_show (supprimer_un_utilisateur);
}


void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*windowlogin;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"fenetre1");
gtk_widget_destroy(w);
windowlogin=create_windowlogin();
gtk_widget_show(windowlogin);
}


void
on_button_retourner_ajout_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1 ;
GtkWidget *treeview1 ;
w=lookup_widget(objet,"ajouter_un_utilisateur");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_utilisateur(treeview1);
}


void
on_button_retourner_modifier_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*fenetre1;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"modifier_un_utilisateur");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);
}


void
on_button_retourner_supprimer_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*fenetre1;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"supprimer_un_utilisateur");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_utilisateur(treeview1);
}


void
on_treeviewwass_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* genre;
gchar* cin;
gchar* role;
gchar* vote;
gchar* numbv;
utilisateur u,u2 ;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model) , &iter, 0,&cin,1,&nom,2,&prenom,3,&role,4,&genre,5,&jour,6,&mois,7,&annee,8,vote,9,numbv, -1);


int x =supprimer_utilisateur("utilisateur.txt",cin);
afficher_utilisateur(treeview);
}

}

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{xa=1;}
}


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{xa=2;}
}


void
on_button_ajouter1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{int i,b,c;


GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;



utilisateur u;
GtkWidget *cin ,*nom ,*prenom,*login,*mdp,*vote,*numbv;
GtkWidget *combobox1 ;




cin=lookup_widget(objet,"cin_ajouter");
nom=lookup_widget(objet,"nom_ajouter");
prenom=lookup_widget(objet,"prenom_ajouter");
login=lookup_widget(objet,"login_ajouter");
mdp=lookup_widget(objet,"mdp_ajouter");
vote=lookup_widget(objet,"vote_ajouter");
numbv=lookup_widget(objet,"numbv_ajouter");
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(u.conx.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(u.conx.mdp,gtk_entry_get_text(GTK_ENTRY(mdp)));
int f=atoi(gtk_entry_get_text(GTK_ENTRY(vote)));
int m=atoi(gtk_entry_get_text(GTK_ENTRY(numbv)));
u.vote=f;
u.numbv=m ;


if(xa==1)
{
strcpy(u.genre,"Homme");
}
if(xa==2)
{
strcpy(u.genre,"Femme");
}

jour=lookup_widget(objet, "spinbutton10");
mois=lookup_widget(objet, "spinbutton20");
annee=lookup_widget(objet, "spinbutton30");

i=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
b=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

u.DDN.jour=i ;
u.DDN.mois=b ;
u.DDN.annee=c ;
combobox1=lookup_widget(objet, "combobox14");
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

int k=ajouter_utilisateur("utilisateur.txt", u) ;

}
void
on_checkbutton_supprimer_utilisateur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if  (gtk_toggle_button_get_active(togglebutton))
{ya=1;}

}


void
on_button_supprimer2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *w ;
GtkWidget *output ;
char cin[30];
w=lookup_widget(objet,"cin_supp");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(w)));
output=lookup_widget(objet,"output_sup");
if(ya==1)

{
int ml= supprimer_utilisateur("utilisateur.txt",cin) ;
  if (ml==1) 
   { gtk_label_set_text(GTK_LABEL(output),"utilisateur supprimer avec succes");} 
  else 
      {gtk_label_set_text(GTK_LABEL(output),"utilisateur n'est pas trouve");}

   }
else 
{gtk_label_set_text(GTK_LABEL(output),"confirmer pour supprimer") ; }
}


/*
void
on_femme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}
*/

void
on_button_modifier1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{int i,b,c;


GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;



utilisateur u;
GtkWidget *cin ,*nom ,*prenom,*login,*mdp,*vote,*numbv;
GtkWidget *combobox1,*output22 ;


output22=cin=lookup_widget(objet,"output500");

cin=lookup_widget(objet,"cin_modifier");
nom=lookup_widget(objet,"nom_modifier");
prenom=lookup_widget(objet,"prenom_modifier");
login=lookup_widget(objet,"login_modifier");
mdp=lookup_widget(objet,"mdp_modifier");
vote=lookup_widget(objet,"vote_modifier");
numbv=lookup_widget(objet,"numbv_modifier");
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(u.conx.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(u.conx.mdp,gtk_entry_get_text(GTK_ENTRY(mdp)));
int f=atoi(gtk_entry_get_text(GTK_ENTRY(vote)));
int m=atoi(gtk_entry_get_text(GTK_ENTRY(numbv)));
u.vote=f;
u.numbv=m ;


if(za==1)
{
strcpy(u.genre,"Homme");
}
if(za==2)
{
strcpy(u.genre,"Femme");
}

jour=lookup_widget(objet, "spinbutton_jour01");
mois=lookup_widget(objet, "spinbutton_mois02");
annee=lookup_widget(objet, "spinbutton_annee02");

i=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
b=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

u.DDN.jour=i ;
u.DDN.mois=b ;
u.DDN.annee=c ;
combobox1=lookup_widget(objet, "combobox40");
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

  int k0=modifier_utilisateur("utilisateur.txt", u,u.cin) ;
         
if (k0==1) 
   { gtk_label_set_text(GTK_LABEL(output22),"modification avec succes");} 
else 
   {gtk_label_set_text(GTK_LABEL(output22),"echec de modification");}


}


void
on_button_afficher_modifier_clicked    (GtkWidget      *objet,
                                        gpointer         user_data)
{
int a;
int i=0;
char cin1[30];

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

GtkWidget *cin ,*nom ,*prenom,*login,*mdp,*vote,*numbv;
GtkWidget *role,*output,*homme,*femme ;



output = lookup_widget(objet, "output_4070");
cin=lookup_widget(objet,"cin_modifier");
nom = lookup_widget(objet, "nom_modifier");
prenom = lookup_widget(objet, "prenom_modifier");
login = lookup_widget(objet, "login_modifier");
mdp = lookup_widget(objet, "mdp_modifier");

jour=lookup_widget(objet, "spinbutton_jour01");
mois=lookup_widget(objet, "spinbutton_mois02");
annee=lookup_widget(objet, "spinbutton_annee02"); 
role=lookup_widget(objet, "combobox40");
homme=lookup_widget(objet, "homme_modifier"); 
femme=lookup_widget(objet, "femme_modifier");
vote=lookup_widget(objet, "vote_modifier");
numbv=lookup_widget(objet, "numbv_modifier");


strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
utilisateur k=chercher_utilisateur("utilisateur.txt" ,cin1) ;

if (strcmp(k.cin,"introuvable")==0)
{gtk_label_set_text(GTK_LABEL(output),"cin n'est pas trouver") ;
}
else {
if (strcmp(k.cin,"introuvable")!=0)
{gtk_label_set_text(GTK_LABEL(output),"cin trouvé") ;

gtk_entry_set_text(GTK_ENTRY(nom),k.nom);
gtk_entry_set_text(GTK_ENTRY(prenom),k.prenom);

gtk_entry_set_text(GTK_ENTRY(login),k.conx.login);
gtk_entry_set_text(GTK_ENTRY(mdp),k.conx.mdp);





if (strcmp("Administrateur",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),0);

if (strcmp("Electeur",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),1);

if (strcmp("Agent_de_bureau_de_vote",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),2);

if (strcmp("Observateur",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),3);



gtk_spin_button_set_value(jour,k.DDN.jour);
gtk_spin_button_set_value(mois,k.DDN.mois);
gtk_spin_button_set_value(annee,k.DDN.annee);

if (strcmp(k.genre,"homme")==0)
{
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (homme),TRUE);
}

else if (strcmp(k.genre,"femme")==0)
{
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (femme),TRUE);
}
char ch1[30] ;
char ch2[30] ;

sprintf(ch1,"%d",k.numbv) ;
sprintf(ch2,"%d",k.vote) ;





gtk_entry_set_text(GTK_ENTRY(numbv),ch1);
gtk_entry_set_text(GTK_ENTRY(vote),ch2);











}


}



}


void
on_homme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ if(gtk_toggle_button_get_active(togglebutton))
    {za=1;}

}


void
on_femme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if(gtk_toggle_button_get_active(togglebutton))
     {za=2;}
}








void
on_button_identifier1_clicked          (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{/*int verif ;
GtkWidget *espace_adminstrateur;
  GtkWidget *espace_electeur;
  GtkWidget *espace_observateur;
  GtkWidget *espace_agent_de_bureau_de_vote;
GtkWidget *login, *password , *fenetre1,*w;
GtkWidget *output;
GtkWidget *treeview1;
char log[30];
char pw[30];
int trouve;
login=lookup_widget(objet_graphique,"login1");
password=lookup_widget(objet_graphique,"mdp1");
strcpy(log,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(pw,gtk_entry_get_text(GTK_ENTRY(password)));
utilisateur u=chercher_utilisateur_souhail("utilisateur.txt", log,pw);
 verif=verif_souhail (log, pw) ;

if (verif==0){
output=lookup_widget(objet_graphique,"msg");
gtk_label_set_text(GTK_LABEL(output),"Incorrect Values");
}
else {if(strcmp(u.role,"Administrateur")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
espace_adminstrateur = create_espace_adminstrateur ();
  gtk_widget_show (espace_adminstrateur);

}
else {   
        if(strcmp(u.role,"Electeur")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
 espace_electeur = create_espace_electeur ();
  gtk_widget_show (espace_electeur);
}
else{ 
    if(strcmp(u.role,"Agent_de_bureau_de_vote")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
 espace_agent_de_bureau_de_vote = create_espace_agent_de_bureau_de_vote ();
  gtk_widget_show (espace_agent_de_bureau_de_vote);
}
else {
        if(strcmp(u.role,"Observateur")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
 espace_observateur = create_espace_observateur ();
  gtk_widget_show (espace_observateur);

    
}

}
    
}
}
}
*/
}


void
on_stat_souhail_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *w,*supprimer_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_destroy(w);
supprimer_un_utilisateur = create_stat_souhail ();
  gtk_widget_show (supprimer_un_utilisateur);

}


void
on_afficher_souhail1_clicked           (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *combobox ,*fenetre1,*treeview1,*w;

char ROLE[100];
combobox=lookup_widget(objet, "combobox4100");
strcpy(ROLE,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
///------------------------------------------------///
if(strcmp(ROLE,"Electeur")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("electeur.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_electeur(treeview1);
}
///-------------------------------------------///

if(strcmp(ROLE,"Administrateur")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("admin.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_administrateur(treeview1);
}


///---------------------------------------///

if(strcmp(ROLE,"Agent_de_bureau_de_vote")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("agent.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_agent(treeview1);
}

//**************************//
if(strcmp(ROLE,"Observateur")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("observateur.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeviewwass");
afficher_observateur1(treeview1);
}


}


void
on_calculer97_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *tvb,*tpe;

float a,b ;

char ch1[30];
char ch2[30];


tvb=lookup_widget(objet,"label287");
tpe=lookup_widget(objet,"label288");

  a= TPE("utilisateur.txt");
     b=TVB("utilisateur.txt");

sprintf(ch1,"%f",a);
sprintf(ch2,"%f",b);



gtk_label_set_text(GTK_LABEL(tvb),ch1);
gtk_label_set_text(GTK_LABEL(tpe),ch2);



}


void
on_retourner_stat0123_clicked          (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"stat_souhail");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);

}





void
on_findrec_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int id;
	char name[20];
	GtkWidget *fenetre_affiche,*sp,*nom;
	GtkWidget *treeview1;
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");
	sp=lookup_widget(objet,"spinrec");
	nom=lookup_widget(objet,"findrec1");
	id =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(sp));
	strcpy(name,gtk_entry_get_text(GTK_ENTRY(nom)));
	treeview1=lookup_widget(fenetre_affiche,"treeviewrec");
	vider(treeview1);
	//tab_cherche (treeview1,id );
	if (strcmp(name,"")==0 )
		tab_cherche (treeview1,id );
	if (strcmp(name,"")!=0)
		tab_cherche2(treeview1,name);
	
}


void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*windowlogin;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"menuobservateur");
gtk_widget_destroy(w);
windowlogin=create_windowlogin();
gtk_widget_show(windowlogin);
}


void
on_acceuilrec_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*windowlogin;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"fenetre_ajout");
gtk_widget_destroy(w);
windowlogin=create_windowlogin();
gtk_widget_show(windowlogin);
}

