#include "BV.h"
#include  <stdio.h>
#include <gtk/gtk.h>
#include  <string.h>
#include  <stdlib.h>
enum{
	EID,
	ECAPELEC,
	ECAPOBS,
	EADR,
	ESALLE,
	EIDAGENT,
	COLUMNS,
};

int totvot(){

    FILE *f = fopen("user.txt", "r");
    if(f == NULL){
        return 0;
    }else{
        int nb = 1;
        char c;
        while((c = fgetc(f)) != EOF){
            if(c == '\n') nb++;
        }
        fclose(f);
        return nb;
    }
}
int controllebv(char chaine[])
{
	int i=0;
	int tr=0;

	for (i=0;i<strlen(chaine);i++){
		if (isdigit(chaine[i]))
			tr=1;
	}
    return tr;
}
int tvb(){
    char ch[50];
    char ch1[50];
    char ch2[50];
    char ch3[50];
    char ch4[50];
    int x;
    FILE *f = fopen("user.txt", "r");
    if(f == NULL){
        return 0;
    }
	else{
        int nb = 0;
        while (fscanf (f,"%s %s %s %s %s %d\n",ch,ch1,ch2,ch3,ch4,&x)!=EOF){
            if(x==0) nb++;
        }
        fclose(f);
        return nb;
    }
}

int ajouterbv( bureau p)
{
    FILE * f=fopen("BV.txt", "a");
    if(f!=NULL)
    { fprintf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,p.salle,p.b_adr,p.id_agentb);
        fclose(f);
        return 1;
    }
    else return 0;
}
void modifierbv( bureau nouv )
{
    bureau p;
    FILE * f=fopen("BV.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF)
        {
            if(strcmp(p.id, nouv.id)==0)
            {
                fprintf(f2,"%s %s %s %d %s %s\n",nouv.id,nouv.cap_elec,nouv.cap_obs,nouv.salle,nouv.b_adr,nouv.id_agentb);
            }
            else
                fprintf(f2,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,p.salle,p.b_adr,p.id_agentb);
        }
    }
    fclose(f);
    fclose(f2);
    remove("BV.txt");
    rename("nouv.txt", "BV.txt");
}
int supprimer_bv( char id[])
{
    int tr=0;
    bureau p;
    FILE *f;
    FILE *tmp ;
    if ((f=fopen("BV.txt","r"))==NULL){
        exit(1);
    }
    if ((tmp=fopen("nouv.txt","w"))==NULL)
        exit(1);
    while (fscanf(f,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,&p.salle,p.b_adr,p.id_agentb)!=EOF){
        if (strcmp(p.id,id)==0){
            tr=1;
	}
	else{
            fprintf(tmp,"%s %s %s %d %s %s\n",p.id,p.cap_elec,p.cap_obs,p.salle,p.b_adr,p.id_agentb);
        }

}
    fclose(f);
    fclose(tmp);
    //remove("BV.txt");
    //rename("nouv.txt","BV.txt");
    return tr;
}
void supprimerbv( bureau p,int choice )
{

    bureau p2 ;
    FILE * f=fopen("BV.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
	    if(f!=NULL && f2!=NULL)
	    {
		while(fscanf(f,"%s %s %s %d %s %s\n",p2.id,p2.cap_elec,p2.cap_obs,&p2.salle,p2.b_adr,p2.id_agentb)!=EOF)
		{
		    if(strcmp(p2.id, p.id)!=0)
		     	 fprintf(f2,"%s %s %s %d %s %s\n",p2.id,p2.cap_elec,p2.cap_obs,p2.salle,p2.b_adr,p2.id_agentb);
		}
	    }
    fclose(f);
    fclose(f2);
    //remove("BV.txt");
    //rename("nouv.txt", "BV.txt");
	//choice=2;
}
void afficherbv(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter ;
	GtkListStore *store;
	char id[20];
	char cap_elec[20];
	char cap_obs[20];
	int salle;
	char b_adr[20];  
	char  id_agentb[20];
	bureau p;
	store =NULL;

	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store=NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cap_elec",renderer,"text",ECAPELEC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cap_obs",renderer,"text",ECAPOBS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("b_adr",renderer,"text",EADR,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id_agentb",renderer,"text",EIDAGENT,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		

	}
	store=gtk_list_store_new (COLUMNS ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("BV.txt", "r");
	if (f==NULL){
		return;
	}
	else {
		f=fopen("BV.txt", "a+");
		while (fscanf(f,"%s %s %s %d %s %s\n",id,cap_elec,cap_obs,&salle,b_adr,id_agentb)!=EOF){
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store ,&iter ,EID ,id ,ECAPELEC, cap_elec ,ECAPOBS,cap_obs,EADR,b_adr,EIDAGENT,id_agentb,-1);
	}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);


}
}

void viderbv(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char id[20];
	char cap_elec[20];
	char cap_obs[20];
	char b_adr[20];  
	char id_agentb[20];;
	store=NULL;

	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if (store==NULL)

	{
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cap_elec",renderer,"text",ECAPELEC,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("cap_obs",renderer,"text",ECAPOBS,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("b_adr",renderer,"text",EADR,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("id_agentb",renderer,"text",EIDAGENT,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	}
		
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	gtk_list_store_append (store, &iter);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

 
}
void validationbv (int choice ){

if (choice==2){
remove("BV.txt");
rename("nouv.txt", "BV.txt");
}
else 
    remove("nouv.txt");
}
bureau chercherbv(char id[])
{
    bureau p;
    bureau p2;
    FILE * f=fopen("BV.txt", "r");
    if(f!=NULL)
    {
        while (fscanf(f,"%s %s %s %d %s %s\n",p2.id,p2.cap_elec,p2.cap_obs,&p2.salle,p2.b_adr,p2.id_agentb)!=EOF)
   
            if(strcmp(p2.id,id)==0)
		{
                	strcpy(p.cap_elec,p2.cap_elec);
			strcpy(p.cap_obs,p2.cap_obs);
			//strcpy(p.salle,p2.salle);//entier 
			strcpy(p.b_adr,p2.b_adr);
			strcpy(p.id_agentb,p2.id_agentb);


        }


fclose(f);
}
return p ;
}


