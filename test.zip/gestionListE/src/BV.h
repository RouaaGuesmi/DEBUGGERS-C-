#ifndef FONCTIONS_H_
#define FONCTIONS_H_
#include <stdio.h>
#include <gtk/gtk.h>
typedef struct 
{
char id[20];
char cap_elec[20];
char cap_obs[20];
int salle;
char b_adr[20];  
char  id_agentb[20];
} bureau ;

int ajouterbv( bureau b);
int totvot();
void modifierbv( bureau b);
int controllebv(char chaine[]);
void supprimerbv( bureau p ,int choice);
bureau chercherbv(char id[]);
void viderbv(GtkWidget *liste);
void afficherbv(GtkWidget *liste);
void validationbv(int choice );
int supprimer_bv( char id[]);
int tvb();
#endif
