#ifndef RECLAMATION_H_INCLUDED
#define RECLAMATION_H_INCLUDED
#include <stdio.h>


typedef struct
{
    char nom [10]; 
    char prenom[10];
    char cin[10];
    int id_rec;
 
}Reclamation;
typedef struct
{
    char nom [20];
    char prenom [20];
    char genre [20];
    int age,cin ;
} personne ;
int nbr_reclamation();
int homme();
int femme();

#endif 
