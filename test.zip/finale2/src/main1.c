#include "stat.h"



int main(){

	int a,b,c;
	a=nbr_reclamation();
	b=homme();
	c=femme();
	printf("nombre de reclamation %d ",a);
	printf("nombre des hommes %d ",b);
	printf("nombre des femmes %d ",c);
	return 0;
}

