#include "stat.h"

int homme(){
  personne p;
    FILE *f = fopen("personne.txt", "r");
    if(f == NULL){
        return 0;
    }
	else{
        int nb = 0;
        while (fscanf (f,"%d %s %s %s %d\n",&p.cin,p.prenom,p.nom,p.genre,&p.age)!=EOF){
            if(strcmp(p.genre,"homme")==0) nb++;
        }
        fclose(f);
        return nb;
    }
}
int femme(){
  personne p;
    FILE *f = fopen("personne.txt", "r");
    if(f == NULL){
        return 0;
    }else{
        int nb = 0;
        while (fscanf (f,"%d %s %s %s %d\n",&p.cin,p.prenom,p.nom,p.genre,&p.age)!=EOF){
            if(strcmp(p.genre,"femme")==0) nb++;
        }
        fclose(f);
        return nb;
 }
}
int nbr_reclamation(){

    FILE *f = fopen("reclamation.txt", "r");
    if(f == NULL){
        return 0;
    }else{
        int nb = 1;
        char c;
        while((c = fgetc(f)) != EOF){
            if(c == '\n') nb++;
        }
        fclose(f);
        return nb;
    }
}

