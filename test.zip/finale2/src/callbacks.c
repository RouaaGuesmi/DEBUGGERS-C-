#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include  "support.h"	
#include "reclamation.h"

int choix[3]={0,0,0};
int choix2[3]={0,0,0};
char rec[70];
char rec2[70];
int choice=1;
void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int wa=0;
	int ka=0;
	int ca=0;
	int ba=0;
	int k;
	char vide[2]="";
	GtkWidget*output ;
	GtkWidget*output1 ;
	GtkWidget*output2 ;
	GtkWidget*output3 ;
	GtkWidget*output4 ;
	GtkWidget*output5 ;
	GtkWidget*combobox1 ;
	GtkWidget*output6,*ch1,*ch2,*ch3 ;
	int a,b,c;
	char mot1[30]="ajout avec succes";
	char mot2[20]="echec d ajout  ";
	char mot3[15]="(invalide)";
	char mot4[50]="il faut choisir un choix ";
	char mot5[50]="il faut choisir une liste";
	char mot6[30]="votre id de reclamatin -> ";
	char mot7[25]="";
	output = lookup_widget(objet, "label10") ;
	output1 = lookup_widget(objet, "label123") ;
	output2 = lookup_widget(objet, "label124") ;
	output3 = lookup_widget(objet, "label125") ;
	output4 = lookup_widget(objet, "label132") ;
	output5 = lookup_widget(objet, "label133") ;
	output6 = lookup_widget(objet, "label135") ;
	combobox1 = lookup_widget(objet, "combobox1") ;
	ch1=lookup_widget(objet,"checkbutton1");
	ch2=lookup_widget(objet,"checkbutton2");
	ch3=lookup_widget(objet,"checkbutton3");

	Reclamation r;
	election e;
	GtkWidget *input1,*input2,*input3;
	GtkWidget *fenetre_ajout;

	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	input1=lookup_widget(objet,"nom");
	input2=lookup_widget(objet,"prenom");
	input3=lookup_widget(objet,"cin");
	k=id();
	sprintf(mot7,"%d",k);
	strcat(mot6,mot7);

	strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(r.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
	a=controlle(r.nom);
	b=controlle(r.prenom);
	c=controlle1(r.cin);
	choix[0]=0;
	choix[1]=0;
	choix[2]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==1)
		choix[0]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==0)
		choix[0]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==1)
		choix[1]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==0)
		choix[1]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==1)
		choix[2]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==0)
		choix[2]=0;
	if ((strcmp(r.nom,vide)==0)||(a==1)){
		gtk_label_set_text(GTK_LABEL(output1),mot3);	
		wa=1;
	}
	else {	
		gtk_label_set_text(GTK_LABEL(output1),"");	
		wa=0;
	}
	if ((strcmp(r.prenom,vide)==0)||(b==1)){

		gtk_label_set_text(GTK_LABEL(output2),mot3);
		ba=1;
		}
	else {
		gtk_label_set_text(GTK_LABEL(output2),"");
		ba=0;
		}
	if ((strcmp(r.cin,vide)==0)||(c==1)){
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		ca=1;
	}
	else 	{
		gtk_label_set_text(GTK_LABEL(output3),"");
		ca=0;
	}
	if ((choix[0]==0) && (choix[1]==0) &&(choix[2]==0)){
		gtk_label_set_text(GTK_LABEL(output4),mot4);
		ka=1;
	}
	else 	{
		gtk_label_set_text(GTK_LABEL(output4),"");
		ka=0;
}

	
	if ((wa==0)&&(ba==0) && (ca==0)&&(ka==0))
	{
		ajouter(r,choix,rec);
		choix[0]=0;
		choix[1]=0;
		choix[2]=0;
		gtk_label_set_text(GTK_LABEL(output),mot1);
		gtk_label_set_text(GTK_LABEL(output1),vide);
		gtk_label_set_text(GTK_LABEL(output2),vide);
		gtk_label_set_text(GTK_LABEL(output3),vide);
		gtk_label_set_text(GTK_LABEL(output4),vide);
		gtk_label_set_text(GTK_LABEL(output5),vide);
		gtk_label_set_text(GTK_LABEL(output6),mot6);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);
		
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output),mot2);
		/*gtk_label_set_text(GTK_LABEL(output1),mot3);
		gtk_label_set_text(GTK_LABEL(output2),mot3);
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		gtk_label_set_text(GTK_LABEL(output4),mot4);
		gtk_label_set_text(GTK_LABEL(output5),mot5);
		gtk_label_set_text(GTK_LABEL(output5),vide);*/
		
	}
	if( (combobox1)==-1)
		gtk_label_set_text(GTK_LABEL(output5),mot5);
	if ((GTK_COMBO_BOX(combobox1))==0)
		gtk_label_set_text(GTK_LABEL(output5),"walaa");
	else 
		gtk_label_set_text(GTK_LABEL(output5),"");
}	

void 
on_afficher_clicked                    (GtkWidget	*objet,
					gpointer 	user_data)
{
	GtkWidget *fenetre_ajout;
	GtkWidget *fenetre_affiche;
	GtkWidget *treeview1;

	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	gtk_widget_destroy(fenetre_ajout);
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");

	fenetre_affiche=create_fenetre_affiche();

	gtk_widget_show(fenetre_affiche);
	treeview1=lookup_widget(fenetre_affiche,"treeview1");
	vider(treeview1);
	afficher(treeview1,rec);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* nom;
	gchar* prenom;
	gchar* cin;
	gchar* id_rec;
	
	Reclamation r;
	GtkTreeModel *model = gtk_tree_view_get_model (treeview) ;

	if (gtk_tree_model_get_iter(model, &iter, path) ){

		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &nom, 1, &prenom, 2,&cin,3,&id_rec-1);
		/*strcpy(r.nom,nom);
		strcpy(r.prenom,prenom) ;
		strcpy(r.cin,cin) ;
		supprimer(r,rec);*/
		afficher(treeview,rec) ;
	}
}


void
on_retour_clicked                      (GtkWidget      *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_affiche;
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");
	gtk_widget_destroy(fenetre_affiche);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);

}


void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *fenetre_affiche,*w1;
	GtkWidget *treeview1;

	w1=lookup_widget(objet,"fenetre_affiche");
	fenetre_affiche=create_fenetre_affiche();
	gtk_widget_show(fenetre_affiche);
	gtk_widget_hide(w1);
	treeview1=lookup_widget(fenetre_affiche,"treeview1");
	vider(treeview1);
	afficher(treeview1,rec);

}


void
on_vider_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_affiche,*w1;
	GtkWidget *treeview1;

	w1=lookup_widget(objet,"fenetre_affiche");
	fenetre_affiche=create_fenetre_affiche();
	gtk_widget_show(fenetre_affiche);
	gtk_widget_hide(w1);
	treeview1=lookup_widget(fenetre_affiche,"treeview1");
	vider(treeview1);
	afficher(treeview1,rec);
	
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_supprime;
	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	gtk_widget_destroy(fenetre_ajout);
	fenetre_supprime=create_fenetre_supprime();
	gtk_widget_show(fenetre_supprime);


}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_modifier;
	fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
	gtk_widget_destroy(fenetre_ajout);
	fenetre_modifier=create_fenetre_modifier();
	gtk_widget_show(fenetre_modifier);
}


void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_ajout,*fenetre_modifier;
	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	gtk_widget_destroy(fenetre_modifier);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);
}


void
on_enregistrer_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int cx[3]={0,0,0};
	char vide[2]="";
	GtkWidget*output ;
	GtkWidget*output1 ;
	GtkWidget*output2 ;
	GtkWidget*output3 ;
	GtkWidget*output4 ;

	char mot1[40]="modification avec succes";
	char mot2[40]="echec de modification !";
	char mot3[15]="(invalide)";
	output = lookup_widget(objet, "label129") ;
	output1 = lookup_widget(objet, "label126") ;
	output2 = lookup_widget(objet, "label127") ;
	output3 = lookup_widget(objet, "label128") ;
	output4=lookup_widget(objet,"label140");
	Reclamation r;
	Reclamation new ;
	
	GtkWidget *input1,*input2,*input3,*ch1,*ch2,*ch3;
	GtkWidget *fenetre_modifier;

	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	input1=lookup_widget(objet,"nom1");
	input2=lookup_widget(objet,"prenom1");
	input3=lookup_widget(objet,"cin1");
	ch1=lookup_widget(objet,"checkbutton7");
	ch2=lookup_widget(objet,"checkbutton8");
	ch3=lookup_widget(objet,"checkbutton9");
	strcpy(new.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(new.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(new.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==1)
		choix2[0]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1))==0)
		choix2[0]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==1)
		choix2[1]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2))==0)
		choix2[1]=0;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==1)
		choix2[2]=1;
	if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch3))==0)
		choix2[2]=0;
	
	
	
	if ((strcmp(new.nom,vide )!=0) && (strcmp(new.prenom,vide )!=0) && (strcmp(new.cin,vide )!=0) &&((choix2[0]!=0) ||(choix2[1]!=0)||(choix2[2]!=0)))
	{	
		modifier(new,rec2,rec,choix2); 
		choix2[0]=0;
		choix2[1]=0;
		choix2[2]=0;
		gtk_label_set_text(GTK_LABEL(output),mot1);
		gtk_label_set_text(GTK_LABEL(output1),vide);
		gtk_label_set_text(GTK_LABEL(output2),vide);
		gtk_label_set_text(GTK_LABEL(output3),vide);
		gtk_label_set_text(GTK_LABEL(output4),"");
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
	}
	else 
	{
		gtk_label_set_text(GTK_LABEL(output),mot2);
		//gtk_label_set_text(GTK_LABEL(output1),mot3);
		gtk_label_set_text(GTK_LABEL(output2),mot3);
		gtk_label_set_text(GTK_LABEL(output3),mot3);
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
		gtk_entry_set_text(GTK_ENTRY(input3),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		gtk_entry_set_text(GTK_ENTRY(input2),vide);
		
	}
}


void
on_supprimer2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char vide1[]="";
	Reclamation r3;
	Reclamation r;
	int idd;
	GtkWidget *input1,*input2,*input3,*output,*id;
	GtkWidget *fenetre_supprime;
	GtkWidget *fenetre_valide;
	fenetre_supprime=lookup_widget(objet,"fenetre_supprime");
	input1=lookup_widget(objet,"nom2");
	input2=lookup_widget(objet,"prenom2");
	input3=lookup_widget(objet,"cin2");
	output=lookup_widget(objet,"label156");
	id=lookup_widget(objet,"spinbutton2");
	idd =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id));

	strcpy(r3.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(r3.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(r3.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
	if ((strcmp(r3.nom,"")!=0) &&(strcmp(r3.prenom,"")!=0) &&(strcmp(r3.cin,"")!=0)){
		supprimer_1(rec,idd);
		gtk_label_set_text(GTK_LABEL(output)," choix fait avec succes ");
		fenetre_valide=create_fenetre_valide();
		gtk_widget_show(fenetre_valide);
	}
	else {	
		gtk_label_set_text(GTK_LABEL(output)," il faut tapez ou chercher votre reclamation a supprimer ");

	}
}


void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_supprime,*fenetre_ajout;
	fenetre_supprime=lookup_widget(objet,"fenetre_supprime");
	gtk_widget_destroy(fenetre_supprime);
	fenetre_ajout=create_fenetre_ajout();
	gtk_widget_show(fenetre_ajout);
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton)){
choix[0]=1;
}
else
	choix[0]=0;
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix[1]=1;
}
else
	choix[1]=0;
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix[2]=1;
}
else
	choix[2]=0;
}


void
on_checkbutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix2[0]=1;
}
if ((gtk_toggle_button_get_active(togglebutton))==-1){
choix2[0]=0;
}

}


void
on_checkbutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix2[1]=1;
}
if ((gtk_toggle_button_get_active(togglebutton))==-1){
choix2[1]=0;
}

}


void
on_checkbutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton)){
choix2[2]=1;
}
if ((gtk_toggle_button_get_active(togglebutton))==-1){
choix2[2]=0;
}

}


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

	char vide[3]="";
	GtkWidget*input ;
	GtkWidget*input1 ;
	GtkWidget*input2 ;
	GtkWidget*output ;
	GtkWidget*ch1 ;
	GtkWidget*ch2 ;
	GtkWidget*ch3 ;
	GtkWidget* id ;
	GtkWidget*output1 ;
	Reclamation r,r2;
	
	char word[50]="reclamation introuvable ";
	char id_st[10];
	int idd ;
	int x=-1;
	int l=0;
	char ident[25];
	GtkWidget *fenetre_modifier;
	fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
	id=lookup_widget(objet,"spinbutton1");
	output=lookup_widget(objet,"label140");
	input=lookup_widget(objet,"nom1");
	input1=lookup_widget(objet,"prenom1");
	input2=lookup_widget(objet,"cin1");
	output1 = lookup_widget(objet, "label129") ;
	ch1=lookup_widget(objet,"checkbutton7");
	ch2=lookup_widget(objet,"checkbutton8");
	ch3=lookup_widget(objet,"checkbutton9");
	strcpy(ident,gtk_entry_get_text(GTK_ENTRY(input2)));
	idd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id));
	gtk_label_set_text(GTK_LABEL(output1),"");
	FILE *f;
	int a=idd;
	f = fopen ("reclamation.txt", "r");
  	if (f!=NULL)
 	{
  		while (fscanf (f,"%s %s %s %s %d\n",r.nom,r.prenom,r.cin,rec,&r.id_rec)!=EOF)
  		{
    			if ((idd==r.id_rec)&&(strcmp(ident,r.cin)==0)){
				x=1;
				l=strlen(rec);
			}
  		}
	fclose (f);
  	}
	
	
	if(x==1)

	{
		r2  = chercher(a,rec);
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
	     	gtk_label_set_text(GTK_LABEL(output),"reclamation trouve");
		gtk_entry_set_text(GTK_ENTRY(input),r2.nom);
		gtk_entry_set_text(GTK_ENTRY(input1),r2.prenom);
		//gtk_entry_set_text(GTK_ENTRY(input2),r2.cin);	
		if(l==16)
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
		if(l==31){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
			}
		if(l==33){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
			}
		if(l==48){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
			}
		if(l==15)
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
		if(l==32){
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),TRUE);}
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
			}
		if(l==17)
			{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),TRUE);}
}
	else {
		gtk_label_set_text(GTK_LABEL(output),word);
		gtk_entry_set_text(GTK_ENTRY(input),vide);
		gtk_entry_set_text(GTK_ENTRY(input1),vide);
		//gtk_entry_set_text(GTK_ENTRY(input2),vide);
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2),FALSE);}
		{gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch3),FALSE);}
}
x=-1;

}	
void
on_rechercher2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int idd;
	int x=-1;
	char vide1[20]="";
	Reclamation r3;
	Reclamation r;
	GtkWidget *input,*input1,*input2,*id,*output;
	GtkWidget *fenetre_supprime;	
	GtkWidget*ch1 ;
	GtkWidget*ch2 ;
	GtkWidget*ch3 ;
	fenetre_supprime=lookup_widget(objet,"fenetre_supprime");
	input=lookup_widget(objet,"nom2");
	input1=lookup_widget(objet,"prenom2");
	id=lookup_widget(objet,"spinbutton2");
	input2=lookup_widget(objet,"cin2");
	idd=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(id));
	output=lookup_widget(objet,"label157");
	FILE *f;
	int tmp=idd;
	int a=idd;
	f = fopen ("reclamation.txt", "r");
  	if (f!=NULL)
 	{
  		while (fscanf (f,"%s %s %s %s %d",r.nom,r.prenom,r.cin,rec,&r.id_rec)!=EOF)
  		{
    			if (idd==r.id_rec)
				x=1;
  		}
     		fclose (f);
  	}
	if(x==1)

	{
	    	Reclamation r2  = chercher(a,rec);
	     	gtk_label_set_text(GTK_LABEL(output),"reclamation trouve");
		gtk_entry_set_text(GTK_ENTRY(input),r2.nom);
		gtk_entry_set_text(GTK_ENTRY(input1),r2.prenom);
		gtk_entry_set_text(GTK_ENTRY(input2),r2.cin);	
	}
	else {	
			gtk_label_set_text(GTK_LABEL(output),"reclamation introuvable");
			gtk_entry_set_text(GTK_ENTRY(input),vide1);
			gtk_entry_set_text(GTK_ENTRY(input1),vide1);
			gtk_entry_set_text(GTK_ENTRY(input2),vide1);	
}
}

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choice=1;
}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton))){
choice=2;
}
}


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_supprime,*fenetre_valide;
	fenetre_valide=lookup_widget(objet,"fenetre_valide");
	validation (choice);
	choice=1;
	gtk_widget_destroy(fenetre_valide);
	
}


void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *fenetre_affiche,*fenetre_stat;
	GtkWidget *treeview1;
	fenetre_stat=lookup_widget(objet,"fenetre_stat");
	gtk_widget_destroy(fenetre_stat);
	fenetre_affiche=create_fenetre_affiche();
	gtk_widget_show(fenetre_affiche);
	treeview1=lookup_widget(fenetre_affiche,"treeview1");
	vider(treeview1);
	afficher(treeview1,rec);
}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	char word1[50]="nombre de reclamation totale : ";
	char word2[50]="taux de participation homme  : ";
	char word3[50]="taux de participation femme  : ";
	char vide1[5];
	char vide2[5];
	char vide3[3];
	GtkWidget*output1 ;
	GtkWidget*output2 ;
	GtkWidget*output3 ;
	GtkWidget*output4 ;
	GtkWidget *fenetre_stat;

	fenetre_stat=lookup_widget(objet,"fenetre_stat");
	output1=lookup_widget(objet,"label149");
	output2=lookup_widget(objet,"label150");
	output3=lookup_widget(objet,"label151");
	int l,m,n;
	l=homme();
	m=femme();
	n=id();
	n=n-1;
	int tot=l+m;	
	float f,d;
	f=((l*100)/tot);
	d=((m*100)/tot);
	gcvt(f, 6, vide1);
        gcvt(d, 6, vide2);
	sprintf(vide3,"%d",n);
	strcat(word1,vide3);
	strcat(word2,vide1);
	strcat(word3,vide2);
	strcat(word2,"%");
	strcat(word3,"%");
	gtk_label_set_text(GTK_LABEL(output1),word1);
	gtk_label_set_text(GTK_LABEL(output2),word2);
	gtk_label_set_text(GTK_LABEL(output3),word3);


}


void
on_stat_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{

	GtkWidget *fenetre_affiche,*fenetre_stat;
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");
	gtk_widget_destroy(fenetre_affiche);
	fenetre_stat=create_fenetre_stat();
	gtk_widget_show(fenetre_stat);
	
}


void
on_button5_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget*combobox1 ;
combobox1 = lookup_widget(objet, "combobox1") ;
election e;
int i;
for (i=0;i<10;i++){
gtk_combo_box_remove_text(GTK_COMBO_BOX(combobox1),i);

}
gtk_combo_box_remove_text(GTK_COMBO_BOX(combobox1),0);
char walaa[50];
   FILE *f = fopen("election.txt", "r");
    if(f == NULL){
        return 0;
    }
else{
    
        while (fscanf (f,"%s %s %s %s %s %s %s %s %s %s %s %d\n",e.id,e.nom,e.orientation,e.nomCT,e.cinT,e.nomC1,e.cinC1,e.nomC2,e.cinC2,e.nomC3,e.cinC3,&e.nbrVote)!=EOF){
		gtk_combo_box_append_text(GTK_COMBO_BOX(combobox1),(e.nom));
        }
}
       fclose(f);

}


void
on_button6_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

}


void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	int id;
	char name[20];
	GtkWidget *fenetre_affiche,*sp,*nom,*out;
	GtkWidget *treeview1;
	fenetre_affiche=lookup_widget(objet,"fenetre_affiche");
	sp=lookup_widget(objet,"spinbutton3");
	nom=lookup_widget(objet,"nomfind");
	out=lookup_widget(objet,"firec");
	id =gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(sp));
	strcpy(name,gtk_entry_get_text(GTK_ENTRY(nom)));
	treeview1=lookup_widget(fenetre_affiche,"treeview1");
	vider(treeview1);
	//tab_cherche (treeview1,id );
	if (strcmp(name,"")!=0){
		tab_cherche2(treeview1,name);
		gtk_label_set_text(GTK_LABEL(out),"");}
	else 
		gtk_label_set_text(GTK_LABEL(out),"introuvable !!");
	
}


void
on_nomfind_insert_text                 (GtkEditable     *editable,
                                        gchar           *new_text,
                                        gint             new_text_length,
                                        gpointer         position,
                                        gpointer         user_data)
{

}

