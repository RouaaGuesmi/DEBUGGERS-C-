#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "observateur.h"
#include "string.h"
#include "stdlib.h"


int genre = 1 ; // 1 : Homme | 2 : Femme
int genreM = 1 ;

void
on_ajouterobsmenu_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(window1);

	window2 = create_ajouterobs ();
	gtk_widget_show(window2 );
}


void
on_affichageobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(window1);

	window2 = create_affichageobs ();
	gtk_widget_show(window2 );
}


void
on_radioHA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genre = 1;
	}
}


void
on_radioFA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genre = 2;
	}
}


void
on_retourAjoutObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"ajouterobs");
	gtk_widget_destroy(window1);

	window2 = create_menuobservateur ();
	gtk_widget_show(window2 );
}


void
on_retourAffichageObs_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"affichageobs");
	gtk_widget_destroy(window1);

	window2 = create_menuobservateur ();
	gtk_widget_show(window2 );
}


void
on_confirmAjoutObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id , *nom , *prenom , *nation , *partieP , *presse , *societeC , *organisationM , *spinJ , *spinM , *spinA , *output ;

	observateur o ;

	id = lookup_widget(objet,"idobs");
	strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(id)));

	nom = lookup_widget(objet,"nomobs");
	strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

	prenom = lookup_widget(objet,"prenomobs");
	strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	nation = lookup_widget(objet,"combobox1");
	strcpy(o.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nation)));

	if(genre == 1){
		strcpy(o.genre,"Homme");
	}else{
		strcpy(o.genre,"Femme");
	}

	partieP = lookup_widget(objet,"politiqueobs");
	strcpy(o.partie_p,gtk_combo_box_get_active_text(GTK_COMBO_BOX(partieP)));

	presse = lookup_widget(objet,"presseobs");
	strcpy(o.presse,gtk_entry_get_text(GTK_ENTRY(presse)));

	societeC = lookup_widget(objet,"civileobs");
	strcpy(o.societe_civ,gtk_entry_get_text(GTK_ENTRY(societeC)));

	organisationM = lookup_widget(objet,"organisationobs");
	strcpy(o.organisationM,gtk_entry_get_text(GTK_ENTRY(organisationM)));

	

	spinJ = lookup_widget(objet,"spinAJ");
	spinM = lookup_widget(objet,"spinAM");
	spinA = lookup_widget(objet,"spinAA");


	o.d.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinJ));
	o.d.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinM));
	o.d.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinA));


	output = lookup_widget(objet,"outputajoutobs");
	char message[200];


	if(rechercher_observateur(o.id) == 0){
		sprintf(message,"Votre ajout a été effectué avec succés !");
		gtk_label_set_text(GTK_LABEL(output),message);
		ajouter_observateur(o);
	}else{
		sprintf(message,"ID Déja existant");
		gtk_label_set_text(GTK_LABEL(output),message);
	}

	
}


void
on_treeviewObs_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
}
void
on_afficherObs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *treeview ;
	treeview = lookup_widget(objet,"treeviewObs");
	afficher_observateur(treeview);
	
}


void
on_afficherStats_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *a1 , *a2 , *a3 , *a4;

	

	
	char text1[20],text2[20],text3[20],text4[20];


	a1 = lookup_widget(objet,"a1");
	int nbTotal = nbTotalObservateur();
	sprintf(text1,"%d",nbTotal);
	gtk_label_set_text(GTK_LABEL(a1),text1);

	
	a2 = lookup_widget(objet,"a2");
	int nbNationnaux = nbTotalObservateurNationnaux(); 
	sprintf(text2,"%d",nbNationnaux);
	gtk_label_set_text(GTK_LABEL(a2),text2);


	a3 = lookup_widget(objet,"a3");
	int nbEtranger = nbTotal - nbNationnaux ; 
	sprintf(text3,"%d",nbEtranger);
	gtk_label_set_text(GTK_LABEL(a3),text3);



	a4 = lookup_widget(objet,"a4");
	float taux = (nbEtranger*100)/nbTotal;
	int percent = 37 ;
	sprintf(text4,"%.2f %c",taux,percent);
	gtk_label_set_text(GTK_LABEL(a4),text4); 
	
}


void
on_menustatsobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"menuobservateur");
	gtk_widget_destroy(window1);

	window2 = create_stats ();
	gtk_widget_show(window2 );
}


void
on_retourStats_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"stats");
	gtk_widget_destroy(window1);

	window2 = create_menuobservateur ();
	gtk_widget_show(window2 );
}


void
on_rechercherObs_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *idObs , *output;
 
	idObs = lookup_widget(objet,"idobsM");
	output = lookup_widget(objet,"outputEdit");
	
	observateur o; 
	char message[200];


	strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(idObs)));

	if(rechercher_observateur(o.id) == 1){
		sprintf(message,"Tapez vos nouveaux données puis\n\t sauvegarder les modifications");
		gtk_label_set_text(GTK_LABEL(output),message);

		GtkWidget  *nom , *prenom , *nation , *partieP , *presse , *societeC , *organisationM , *spinJ , *spinM , *spinA ;


		nom = lookup_widget(objet,"nomobsM");
		gtk_entry_set_text(GTK_ENTRY(nom),observateur_data(o.id).nom);

		prenom = lookup_widget(objet,"prenomobsM");
		gtk_entry_set_text(GTK_ENTRY(prenom),observateur_data(o.id).prenom);

		nation = lookup_widget(objet,"combobox2");
		int comboValue = 0 ;
		char oldNation[40];
		strcpy(oldNation,observateur_data(o.id).nationalite);
		if(strcmp(oldNation,"Etrangere") == 0){
			comboValue = 1;
		}
		gtk_combo_box_set_active(nation,comboValue);



		partieP = lookup_widget(objet,"politiqueobsM");
		char oldPartie_p[40];
		strcpy(oldPartie_p,observateur_data(o.id).partie_p);

		comboValue = 0 ;
		if(strcmp(oldPartie_p,"Center") == 0){
			comboValue = 1;
		}else if(strcmp(oldPartie_p,"Gauche") == 0){
			comboValue = 2;
		}

		gtk_combo_box_set_active(partieP,comboValue);


		presse = lookup_widget(objet,"presseobsM");
		gtk_entry_set_text(GTK_ENTRY(presse),observateur_data(o.id).presse);

		societeC = lookup_widget(objet,"civileobsM");
		gtk_entry_set_text(GTK_ENTRY(societeC),observateur_data(o.id).societe_civ);

		organisationM = lookup_widget(objet,"organisationobsM");
		gtk_entry_set_text(GTK_ENTRY(organisationM),observateur_data(o.id).organisationM);


		

		spinJ = lookup_widget(objet,"spinMJ");
		spinM = lookup_widget(objet,"spinMM");
		spinA = lookup_widget(objet,"spinMA");

		gtk_spin_button_set_value(spinJ,observateur_data(o.id).d.j);
		gtk_spin_button_set_value(spinM,observateur_data(o.id).d.m);
		gtk_spin_button_set_value(spinA,observateur_data(o.id).d.a);


	}else{
		sprintf(message,"ID Non existant !");
		gtk_label_set_text(GTK_LABEL(output),message);
	}
}


void
on_radioHM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genreM = 1;
	}
}


void
on_radioFM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if(gtk_toggle_button_get_active(togglebutton)){
		genreM = 2;
	}
}


void
on_enregistrerModObs_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id , *nom , *prenom , *nation , *partieP , *presse , *societeC , *organisationM , *spinJ , *spinM , *spinA , *output ;

	observateur o ;

	id = lookup_widget(objet,"idobsM");
	strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(id)));

	nom = lookup_widget(objet,"nomobsM");
	strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));

	prenom = lookup_widget(objet,"prenomobsM");
	strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	nation = lookup_widget(objet,"combobox2");
	strcpy(o.nationalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nation)));

	if(genreM == 1){
		strcpy(o.genre,"Homme");
	}else{
		strcpy(o.genre,"Femme");
	}

	partieP = lookup_widget(objet,"politiqueobsM");
	strcpy(o.partie_p,gtk_combo_box_get_active_text(GTK_COMBO_BOX(partieP)));

	presse = lookup_widget(objet,"presseobsM");
	strcpy(o.presse,gtk_entry_get_text(GTK_ENTRY(presse)));

	societeC = lookup_widget(objet,"civileobsM");
	strcpy(o.societe_civ,gtk_entry_get_text(GTK_ENTRY(societeC)));

	organisationM = lookup_widget(objet,"organisationobsM");
	strcpy(o.organisationM,gtk_entry_get_text(GTK_ENTRY(organisationM)));

	

	spinJ = lookup_widget(objet,"spinMJ");
	spinM = lookup_widget(objet,"spinMM");
	spinA = lookup_widget(objet,"spinMA");


	o.d.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinJ));
	o.d.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinM));
	o.d.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinA));


	output = lookup_widget(objet,"outputEdit");
	char message[200];

	if(rechercher_observateur(o.id) == 1){
		sprintf(message,"Votre  observateur a été modifié avec succés !");
		gtk_label_set_text(GTK_LABEL(output),message);
		modifier_observateur(o);
	}else{
		sprintf(message,"ID Non existant");
		gtk_label_set_text(GTK_LABEL(output),message);
	}

}


void
on_retourModifObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"modifObs");
	gtk_widget_destroy(window1);

	window2 = create_affichageobs ();
	gtk_widget_show(window2 );
}


void
on_modifierParmObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1 , *window2 ;
	window1 = lookup_widget(objet,"affichageobs");
	gtk_widget_destroy(window1);

	window2 = create_modifObs ();
	gtk_widget_show(window2 );
}


void
on_supprimerObservateur_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *id , *output ;

	char idObs[30] ; 
	char message[200];

	id = lookup_widget(objet,"idobsM");
	strcpy(idObs,gtk_entry_get_text(GTK_ENTRY(id)));

	output = lookup_widget(objet,"outputEdit");

	if(rechercher_observateur(idObs) == 1){
		sprintf(message,"Votre  observateur a été Supprimer avec succés !");
		gtk_label_set_text(GTK_LABEL(output),message);
		supprimer_observateur(idObs);
	}else{
		sprintf(message,"ID Non existant");
		gtk_label_set_text(GTK_LABEL(output),message);
	}
	

}


void
on_confirm_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}



