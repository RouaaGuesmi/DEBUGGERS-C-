#ifndef __OBSERVATEUR__H__
#define __OBSERVATEUR__H__


typedef struct
{
	int j;
	int m;
	int a;
}date;

typedef struct
{
	char id[30];
	char nom[30];
	char prenom[30];
	char nationalite[30];
	char genre[30];
	char partie_p[30];
	char presse[30];
	char societe_civ[30];
	char organisationM[30];
	date d;	
}observateur ;

void ajouter_observateur(observateur o);
void supprimer_observateur(char id[]);
void modifier_observateur(observateur o);
void afficher_observateur(GtkWidget *liste);

int rechercher_observateur(char id[]);
observateur observateur_data(char id[]);

int nbTotalObservateur();
int nbTotalObservateurNationnaux() ;


#endif
