#include <gtk/gtk.h>


void
on_ajouterobsmenu_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affichageobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radioHA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radioFA_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_retourAjoutObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourAffichageObs_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmAjoutObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeviewObs_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficherObs_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherStats_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_menustatsobs_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourStats_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercherObs_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radioHM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radioFM_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_enregistrerModObs_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourModifObs_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierParmObs_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerObservateur_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirm_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
